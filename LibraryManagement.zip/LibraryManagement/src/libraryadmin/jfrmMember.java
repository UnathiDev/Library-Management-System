/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package libraryadmin;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.awt.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import librarymanagement.LibraryManagement;
import sqlconnect.SQLConnect;
import java.text.*;

/**
 *
 * @author Unathi Okhue
 */
public class jfrmMember extends javax.swing.JFrame {
    public jfrmMember() {
        initComponents();
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String formattedDate = today.format(formatter);
        jtxfRegistrationDate.setText(formattedDate);
        jtxfRegistrationDate.setEditable(false);
        jtxfRegistrationDate.setBackground(new Color(255,255,255));
        
        jlblMembershipStatus.setText("Membership Status: Inactive");
        jlblMembershipStatus.setBackground(new Color(51,153,255));
    }
    private static final String[] VALID_DOMAINS = {"skye.com", "gmail.com", "yahoo.com", "outlook.com", "icloud.com", "protonmail.com",
                                                    "zoho.com", "aol.com", "tutanota.com", "gmx.com", "fastmail.com", "mweb.co.za",
                                                    "telkomsa.net", "afrihost.com", "vodamail.co.za"};
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpnlBackground = new javax.swing.JPanel();
        jlblSubmit = new javax.swing.JLabel();
        jlblReset = new javax.swing.JLabel();
        jlblNewBook = new javax.swing.JLabel();
        jlblReturn = new javax.swing.JLabel();
        jspComponents = new javax.swing.JScrollPane();
        jpnlComponents = new javax.swing.JPanel();
        jtxfName = new javax.swing.JTextField();
        jlblPersonalDetails = new javax.swing.JLabel();
        jsepName = new javax.swing.JSeparator();
        jlblLastName = new javax.swing.JLabel();
        jsepLastName = new javax.swing.JSeparator();
        jsepIDNumber = new javax.swing.JSeparator();
        jlblIDNumber = new javax.swing.JLabel();
        jlblContactNumber = new javax.swing.JLabel();
        jftxfIDNumber = new javax.swing.JFormattedTextField();
        jtxfLastName = new javax.swing.JTextField();
        jftxfContactNumber = new javax.swing.JFormattedTextField();
        jsepContactNumber = new javax.swing.JSeparator();
        jsepEmail = new javax.swing.JSeparator();
        jlblEmail = new javax.swing.JLabel();
        jtxfEmail = new javax.swing.JTextField();
        jlblAddress = new javax.swing.JLabel();
        jsepAddress = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtxaAddress = new javax.swing.JTextArea();
        jlblName = new javax.swing.JLabel();
        jlblMembershipDetails = new javax.swing.JLabel();
        jsepMembershipID = new javax.swing.JSeparator();
        jtxfMembershipID = new javax.swing.JTextField();
        jlblMembershipID = new javax.swing.JLabel();
        jlblRegistrationDate = new javax.swing.JLabel();
        jtxfRegistrationDate = new javax.swing.JTextField();
        jsepRegistrationDate = new javax.swing.JSeparator();
        jlblMembershipType = new javax.swing.JLabel();
        jcomboMembershipType = new javax.swing.JComboBox<>();
        jlblMembershipStatus = new javax.swing.JLabel();
        jlblPaymeentDetails = new javax.swing.JLabel();
        jcomboPaymentMethod = new javax.swing.JComboBox<>();
        jlblPaymentMethod = new javax.swing.JLabel();
        jlblPaymentReference = new javax.swing.JLabel();
        jtxfPaymentReference = new javax.swing.JTextField();
        jsepPaymentReference = new javax.swing.JSeparator();
        jftxfAccountNumber = new javax.swing.JFormattedTextField();
        jlblAccountNumber = new javax.swing.JLabel();
        jsepAccountNumber = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jpnlBackground.setBackground(new java.awt.Color(255, 255, 255));

        jlblSubmit.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblSubmit.setForeground(new java.awt.Color(51, 153, 255));
        jlblSubmit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblSubmit.setText("Submit");
        jlblSubmit.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblSubmit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblSubmitMousePressed(evt);
            }
        });

        jlblReset.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblReset.setForeground(new java.awt.Color(51, 153, 255));
        jlblReset.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblReset.setText("Reset");
        jlblReset.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblReset.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblResetMousePressed(evt);
            }
        });

        jlblNewBook.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jlblNewBook.setForeground(new java.awt.Color(51, 153, 255));
        jlblNewBook.setText("Add a new member");

        jlblReturn.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblReturn.setForeground(new java.awt.Color(51, 153, 255));
        jlblReturn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblReturn.setText("Retrun");
        jlblReturn.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblReturn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblReturnMousePressed(evt);
            }
        });

        jpnlComponents.setBackground(new java.awt.Color(255, 255, 255));

        jtxfName.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfName.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfName.setBorder(null);
        jtxfName.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfNameMouseExited(evt);
            }
        });

        jlblPersonalDetails.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jlblPersonalDetails.setForeground(new java.awt.Color(51, 153, 255));
        jlblPersonalDetails.setText("Personal Details");
        jlblPersonalDetails.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));

        jsepName.setForeground(new java.awt.Color(51, 153, 255));

        jlblLastName.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblLastName.setForeground(new java.awt.Color(51, 153, 255));
        jlblLastName.setText("Last Name");

        jsepLastName.setForeground(new java.awt.Color(51, 153, 255));

        jsepIDNumber.setForeground(new java.awt.Color(51, 153, 255));

        jlblIDNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblIDNumber.setForeground(new java.awt.Color(51, 153, 255));
        jlblIDNumber.setText("ID Number");

        jlblContactNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblContactNumber.setForeground(new java.awt.Color(51, 153, 255));
        jlblContactNumber.setText("Contact Number");

        jftxfIDNumber.setBorder(null);
        try {
            jftxfIDNumber.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("######-###-###-#")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jftxfIDNumber.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jftxfIDNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jftxfIDNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jftxfIDNumberActionPerformed(evt);
            }
        });

        jtxfLastName.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfLastName.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfLastName.setBorder(null);
        jtxfLastName.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfLastNameMouseExited(evt);
            }
        });

        jftxfContactNumber.setBorder(null);
        try {
            jftxfContactNumber.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("+27-##-###-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jftxfContactNumber.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jftxfContactNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N

        jsepContactNumber.setForeground(new java.awt.Color(51, 153, 255));

        jsepEmail.setForeground(new java.awt.Color(51, 153, 255));

        jlblEmail.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblEmail.setForeground(new java.awt.Color(51, 153, 255));
        jlblEmail.setText("Email");

        jtxfEmail.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfEmail.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfEmail.setBorder(null);
        jtxfEmail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfEmailMouseExited(evt);
            }
        });

        jlblAddress.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblAddress.setForeground(new java.awt.Color(51, 153, 255));
        jlblAddress.setText("Address");

        jsepAddress.setForeground(new java.awt.Color(51, 153, 255));

        jtxaAddress.setColumns(20);
        jtxaAddress.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxaAddress.setRows(5);
        jtxaAddress.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxaAddressMouseExited(evt);
            }
        });
        jScrollPane1.setViewportView(jtxaAddress);

        jlblName.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblName.setForeground(new java.awt.Color(51, 153, 255));
        jlblName.setText("Name");

        jlblMembershipDetails.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jlblMembershipDetails.setForeground(new java.awt.Color(51, 153, 255));
        jlblMembershipDetails.setText("Membership Details");
        jlblMembershipDetails.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));

        jsepMembershipID.setForeground(new java.awt.Color(51, 153, 255));

        jtxfMembershipID.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfMembershipID.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfMembershipID.setBorder(null);
        jtxfMembershipID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jtxfMembershipIDMouseEntered(evt);
            }
        });

        jlblMembershipID.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblMembershipID.setForeground(new java.awt.Color(51, 153, 255));
        jlblMembershipID.setText("Membership ID");

        jlblRegistrationDate.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblRegistrationDate.setForeground(new java.awt.Color(51, 153, 255));
        jlblRegistrationDate.setText("Date of Registration");

        jtxfRegistrationDate.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfRegistrationDate.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfRegistrationDate.setBorder(null);

        jsepRegistrationDate.setForeground(new java.awt.Color(51, 153, 255));

        jlblMembershipType.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblMembershipType.setForeground(new java.awt.Color(51, 153, 255));
        jlblMembershipType.setText("Membership Type");

        jcomboMembershipType.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboMembershipType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Student", "Adult", "Senior" }));

        jlblMembershipStatus.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblMembershipStatus.setForeground(new java.awt.Color(51, 153, 255));
        jlblMembershipStatus.setText("Membership Status:");

        jlblPaymeentDetails.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jlblPaymeentDetails.setForeground(new java.awt.Color(51, 153, 255));
        jlblPaymeentDetails.setText("Payment Details");
        jlblPaymeentDetails.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));

        jcomboPaymentMethod.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboPaymentMethod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Credit Card", "Debit Card", "PayPal", "Bank Transfer" }));

        jlblPaymentMethod.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblPaymentMethod.setForeground(new java.awt.Color(51, 153, 255));
        jlblPaymentMethod.setText("Payment Method");

        jlblPaymentReference.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblPaymentReference.setForeground(new java.awt.Color(51, 153, 255));
        jlblPaymentReference.setText("Payment Reference");

        jtxfPaymentReference.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfPaymentReference.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfPaymentReference.setBorder(null);

        jsepPaymentReference.setForeground(new java.awt.Color(51, 153, 255));

        jftxfAccountNumber.setBorder(null);
        try {
            jftxfAccountNumber.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("######-###-###-#")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jftxfAccountNumber.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jftxfAccountNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N

        jlblAccountNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblAccountNumber.setForeground(new java.awt.Color(51, 153, 255));
        jlblAccountNumber.setText("Account Number");

        jsepAccountNumber.setForeground(new java.awt.Color(51, 153, 255));

        javax.swing.GroupLayout jpnlComponentsLayout = new javax.swing.GroupLayout(jpnlComponents);
        jpnlComponents.setLayout(jpnlComponentsLayout);
        jpnlComponentsLayout.setHorizontalGroup(
            jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addComponent(jsepAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlblAccountNumber)
                                    .addComponent(jftxfAccountNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jsepAccountNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jsepPaymentReference, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
                                    .addComponent(jlblPaymentReference)
                                    .addComponent(jtxfPaymentReference)))
                            .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jsepName, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jtxfName, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jlblName))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jlblLastName)
                                        .addComponent(jsepLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jtxfLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(jlblIDNumber)
                                .addComponent(jftxfIDNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jsepIDNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jlblContactNumber)
                                        .addComponent(jsepContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jftxfContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jlblEmail)
                                        .addComponent(jsepEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jtxfEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(jlblAddress)
                                .addComponent(jlblPersonalDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jsepMembershipID, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jtxfMembershipID, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jlblRegistrationDate)
                                    .addComponent(jtxfRegistrationDate, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(12, 12, 12)
                                .addComponent(jcomboMembershipType, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addComponent(jlblMembershipID)
                                .addGap(146, 146, 146)
                                .addComponent(jlblMembershipType))
                            .addComponent(jlblMembershipDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 492, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlblMembershipStatus)
                            .addComponent(jlblPaymeentDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 492, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlblPaymentMethod)
                            .addComponent(jcomboPaymentMethod, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jsepRegistrationDate, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(174, Short.MAX_VALUE))))
        );
        jpnlComponentsLayout.setVerticalGroup(
            jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblPersonalDetails)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblLastName)
                    .addComponent(jlblName))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtxfName, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxfLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jsepName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jsepLastName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jlblIDNumber)
                .addGap(4, 4, 4)
                .addComponent(jftxfIDNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(jsepIDNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblContactNumber)
                    .addComponent(jlblEmail))
                .addGap(4, 4, 4)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jftxfContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxfEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jsepContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jsepEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addComponent(jlblAddress)
                .addGap(12, 12, 12)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jsepAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(jlblMembershipDetails)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblMembershipID)
                    .addComponent(jlblMembershipType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jcomboMembershipType, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addComponent(jtxfMembershipID, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jsepMembershipID, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblRegistrationDate)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtxfRegistrationDate, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jsepRegistrationDate, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jlblMembershipStatus)
                .addGap(55, 55, 55)
                .addComponent(jlblPaymeentDetails)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addComponent(jlblPaymentMethod)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jcomboPaymentMethod, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblAccountNumber)
                        .addGap(4, 4, 4)
                        .addComponent(jftxfAccountNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(jsepAccountNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addComponent(jlblPaymentReference)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtxfPaymentReference, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jsepPaymentReference, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jspComponents.setViewportView(jpnlComponents);

        javax.swing.GroupLayout jpnlBackgroundLayout = new javax.swing.GroupLayout(jpnlBackground);
        jpnlBackground.setLayout(jpnlBackgroundLayout);
        jpnlBackgroundLayout.setHorizontalGroup(
            jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                        .addComponent(jlblNewBook)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                        .addComponent(jspComponents, javax.swing.GroupLayout.DEFAULT_SIZE, 684, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlblSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jlblReset, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jlblReturn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jpnlBackgroundLayout.setVerticalGroup(
            jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                        .addComponent(jlblReturn, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblReset, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                        .addComponent(jlblNewBook)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jspComponents, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jpnlBackground, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpnlBackground, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jlblSubmitMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblSubmitMousePressed
        String memberFirstName, memberLastName, memberIDNumber, memberContactNumber, memberEmail, memberAddress;
        String membershipID, membershipType, strRegistrationDate, membershipStatus;
        String paymentMethod, accountNumber, paymentReference;
        String memberPaymentQuery, memberQuery, membershipQuery, memberLoginQuery, memberLoanQuery;

        memberFirstName = jtxfName.getText();
        memberLastName = jtxfLastName.getText();
        memberIDNumber = jftxfIDNumber.getText();
        memberContactNumber = jftxfContactNumber.getText();
        memberEmail = jtxfEmail.getText();
        memberAddress = jtxaAddress.getText();
        
        membershipID = jtxfMembershipID.getText();
        membershipType = (String) jcomboMembershipType.getSelectedItem();
        strRegistrationDate = jtxfRegistrationDate.getText();
        membershipStatus = "ACTIVE";
        
        paymentMethod = (String) jcomboPaymentMethod.getSelectedItem();
        accountNumber = jftxfAccountNumber.getText();
        paymentReference = jtxfPaymentReference.getText();
        

        if (memberFirstName == null || memberLastName == null || memberIDNumber == null || memberContactNumber == null ||
            memberEmail == null || memberAddress == null ||membershipID == null || membershipType == null || 
            strRegistrationDate == null || accountNumber == null || paymentReference == null) {
            JOptionPane.showMessageDialog(null, "Missing fields.\nPlease makes sure no fields are left blank.", "Request unsuccessfull", JOptionPane.ERROR_MESSAGE);
        } else if (!isValidDomain(memberEmail)){
            JOptionPane.showMessageDialog(null, "Invalid email provided.\nPlease check the email field.", "Request unsuccessfull", JOptionPane.ERROR_MESSAGE);
        } else if(!validString(memberFirstName) || !validString(memberLastName) || !memberAddress.matches("[a-zA-Z0-9 ]+")) {
            JOptionPane.showMessageDialog(null, "Use of illegal characters found.\nPlease check all fields.", "Request unsuccessfull", JOptionPane.ERROR_MESSAGE);
        } else{
            try {
                memberPaymentQuery = "INSERT INTO tblMemberPayment VALUES (?, ?, ?, ?)";
                memberQuery = "INSERT INTO tblMembers VALUES (?, ?, ?, ?, ?, ?)";
                membershipQuery = "INSERT INTO tblMembership VALUES (?, ?, ?, ?)";
                memberLoginQuery = "INSERT INTO tblAdmin VALUES (?, ?, ?, ?)";
                memberLoanQuery = "INSERT INTO tblLoans VALUES (?, ?, ?, ?, ?, ?, ?)";
                
                Connection connect = SQLConnect.connect();
                PreparedStatement statementPayment = connect.prepareStatement(memberPaymentQuery);
                statementPayment.setString(1, membershipID);
                statementPayment.setString(2, paymentMethod);
                statementPayment.setString(3, accountNumber);
                statementPayment.setString(4, paymentReference);
                
                PreparedStatement statementMembers = connect.prepareStatement(memberQuery);
                statementMembers.setString(1, membershipID);
                statementMembers.setString(2, memberFirstName + " " + memberLastName);
                statementMembers.setString(3, memberAddress);
                statementMembers.setString(4, memberContactNumber);
                statementMembers.setString(5, memberEmail);
                statementMembers.setString(6, memberIDNumber);
                
                PreparedStatement statementMembership = connect.prepareStatement(membershipQuery);
                statementMembership.setString(1, membershipID);
                statementMembership.setString(2, membershipStatus);
                statementMembership.setString(3, membershipType);
                statementMembership.setString(4, strRegistrationDate);
                
                PreparedStatement statementAdmin = connect.prepareStatement(memberLoginQuery);
                statementAdmin.setString(1, membershipID);
                statementAdmin.setString(2, encrypt(memberFirstName.toLowerCase()));
                statementAdmin.setBoolean(3, false);
                statementAdmin.setString(4, "LU");
                
                PreparedStatement statementLoan = connect.prepareStatement(memberLoanQuery);
                statementLoan.setString(1, "LN-" + membershipID);
                statementLoan.setString(2, membershipID);
                statementLoan.setDate(3, null);
                statementLoan.setDate(4, null);
                statementLoan.setDate(5, null);
                statementLoan.setDouble(6, 0);
                statementLoan.setString(7, null);
                
                int paymentRows = statementPayment.executeUpdate();
                int membersRows = statementMembers.executeUpdate();
                int membershipRows = statementMembership.executeUpdate();
                int adminRows = statementAdmin.executeUpdate();
                int adminLoan = statementLoan.executeUpdate();

                if (paymentRows > 0 && membersRows > 0 && membershipRows > 0 && adminRows > 0 && adminLoan > 0) {
                    JOptionPane.showMessageDialog(null, "New member " + memberFirstName + " " + memberLastName + "\n[" + membershipID + "] has been added.", "Operation successfull", JOptionPane.INFORMATION_MESSAGE);
                    jlblMembershipStatus.setText("Membership Status: ACTIVE");
                    jlblMembershipStatus.setBackground(new Color(0,255,0));
                } else {
                    JOptionPane.showMessageDialog(null, "ERROR! Unable to record new member.\nPlease check all info provided and try again", "Operation failed", JOptionPane.ERROR_MESSAGE);
                }
                connect.close();
                statementPayment.close();
                statementMembers.close();
                statementMembership.close();
                statementAdmin.close();
                statementLoan.close();
            } catch (HeadlessException | SQLException e) {
                JOptionPane.showMessageDialog(null, "Unable to connect to database at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
                System.out.println(e);
            }catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Unable to connect to perform operation at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_jlblSubmitMousePressed

    private void jlblResetMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblResetMousePressed
        int result = JOptionPane.showConfirmDialog(null, "Are you sure you would like to continue?\nAll progress made to this point will be lost!", "Confirm Action", JOptionPane.YES_NO_OPTION);
        
        if (result == JOptionPane.YES_OPTION) {
            jtxfName.setText(null);
            jtxfLastName.setText(null);
            jftxfIDNumber.setText(null);
            jftxfContactNumber.setText(null);
            jtxfEmail.setText(null);
            jtxaAddress.setText(null);
            jtxfMembershipID.setText(null);
            jcomboMembershipType.setSelectedItem(0);
            jtxfRegistrationDate.setText(null);
            jcomboPaymentMethod.setSelectedItem(0);
            jftxfAccountNumber.setText(null);
            jtxfPaymentReference.setText(null);
            jtxfName.setFocusable(true);
        } else {
        }
    }//GEN-LAST:event_jlblResetMousePressed

    private void jlblReturnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblReturnMousePressed
        LibraryManagement library = new LibraryManagement();
        library.memberMenu = new jfrmMemberMenu();
        library.memberMenu.setLocationRelativeTo(null);
        library.memberMenu.setVisible(true);
        dispose();
    }//GEN-LAST:event_jlblReturnMousePressed

    private void jftxfIDNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jftxfIDNumberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jftxfIDNumberActionPerformed

    private void jtxfMembershipIDMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfMembershipIDMouseEntered
        String lastName, IDNumber, memberType;
        lastName = jtxfLastName.getText();
        IDNumber = jftxfIDNumber.getText();
        memberType = (String) jcomboMembershipType.getSelectedItem();
        
        if (" ".equals(lastName)  || " ".equals(IDNumber) || " ".equals(memberType)) {
            
        } else {
           jtxfMembershipID.setText(createMemberID(lastName, "", IDNumber, memberType)); 
           jtxfMembershipID.setEditable(false);
           jtxfMembershipID.setBackground(new Color(255,255,255));
           
           jtxfPaymentReference.setText(createMemberID(lastName, "LIB-", IDNumber, memberType)); 
           jtxfPaymentReference.setEditable(false);
           jtxfPaymentReference.setBackground(new Color(255,255,255));
        }
    }//GEN-LAST:event_jtxfMembershipIDMouseEntered

    private void jtxfEmailMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfEmailMouseExited
        String inEmail = jtxfEmail.getText();
        if (isValidDomain(inEmail)) {
            jsepEmail.setForeground(new Color(51,153,255));
        } else {
            jsepEmail.setForeground(new Color(255,0,0));
        }
    }//GEN-LAST:event_jtxfEmailMouseExited

    private void jtxfNameMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfNameMouseExited
        String testName = jtxfName.getText();
        if (validString(testName)) {
            jsepName.setForeground(new Color(51,153,255));
        } else {
            jsepName.setForeground(new Color(255,0,0));
        }
    }//GEN-LAST:event_jtxfNameMouseExited

    private void jtxfLastNameMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfLastNameMouseExited
        String testLastName = jtxfLastName.getText();
        if (validString(testLastName)) {
            jsepLastName.setForeground(new Color(51,153,255));
        } else {
            jsepLastName.setForeground(new Color(255,0,0));
        }
    }//GEN-LAST:event_jtxfLastNameMouseExited

    private void jtxaAddressMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxaAddressMouseExited
        String testAddress = jtxaAddress.getText();
        if (testAddress.matches("[a-zA-Z0-9 ]+")) {
            jsepAddress.setForeground(new Color(51,153,255));
        } else {
            jsepAddress.setForeground(new Color(255,0,0));
        }
    }//GEN-LAST:event_jtxaAddressMouseExited

    public String createMemberID(String inLastName, String temp, String inIDNumber, String inMemberType){
        //e.g.: SKYE-OKH-123
        // SKYE + Surname + (Code from ID + Member Type)
        int code = 0, subID = Integer.parseInt(inIDNumber.substring(7, 9));
        
        if (null != inMemberType) switch (inMemberType) {
            case "Student" -> code = 1 + subID;
            case "Adult" -> code = 2 + subID;
            case "Senior" -> code = 3 + subID;
            default -> {
            }
        }
        
        return "SKYE-" + temp + inLastName.substring(0, 3).toUpperCase() + "-" + code;
    }
    
    public static boolean isValidDomain(String email) {
        String[] parts = email.split("@");
        if (parts.length != 2) {
            return false;
        }

        String domain = parts[1];
        for (String validDomain : VALID_DOMAINS) {
            if (domain.equals(validDomain)) {
                return true;
            }
        }
        return false;
    }
    
    boolean validString(String inStr){
        return inStr.matches("[a-zA-Z]+");
    }
    
    public static String encrypt(String plainText) {
        StringBuilder encryptedText = new StringBuilder();
        int shift = 4;
        for (char c : plainText.toCharArray()) {
            if (Character.isLetter(c)){
                char shiftedChar = (char) (c + shift);
                if (Character.isUpperCase(c) && shiftedChar > 'Z') {
                    shiftedChar = (char) ('A' + shiftedChar - 'Z' - 1);
                } else if (Character.isLowerCase(c) && shiftedChar > 'z') {
                    shiftedChar = (char) ('a' + shiftedChar - 'z' - 1);
                }
                encryptedText.append(shiftedChar);
            } else {
                encryptedText.append(c);
            }
        }
        return encryptedText.toString();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(jfrmMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(jfrmMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(jfrmMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(jfrmMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new jfrmMember().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> jcomboMembershipType;
    private javax.swing.JComboBox<String> jcomboPaymentMethod;
    private javax.swing.JFormattedTextField jftxfAccountNumber;
    private javax.swing.JFormattedTextField jftxfContactNumber;
    private javax.swing.JFormattedTextField jftxfIDNumber;
    private javax.swing.JLabel jlblAccountNumber;
    private javax.swing.JLabel jlblAddress;
    private javax.swing.JLabel jlblContactNumber;
    private javax.swing.JLabel jlblEmail;
    private javax.swing.JLabel jlblIDNumber;
    private javax.swing.JLabel jlblLastName;
    private javax.swing.JLabel jlblMembershipDetails;
    private javax.swing.JLabel jlblMembershipID;
    private javax.swing.JLabel jlblMembershipStatus;
    private javax.swing.JLabel jlblMembershipType;
    private javax.swing.JLabel jlblName;
    private javax.swing.JLabel jlblNewBook;
    private javax.swing.JLabel jlblPaymeentDetails;
    private javax.swing.JLabel jlblPaymentMethod;
    private javax.swing.JLabel jlblPaymentReference;
    private javax.swing.JLabel jlblPersonalDetails;
    private javax.swing.JLabel jlblRegistrationDate;
    private javax.swing.JLabel jlblReset;
    private javax.swing.JLabel jlblReturn;
    private javax.swing.JLabel jlblSubmit;
    private javax.swing.JPanel jpnlBackground;
    private javax.swing.JPanel jpnlComponents;
    private javax.swing.JSeparator jsepAccountNumber;
    private javax.swing.JSeparator jsepAddress;
    private javax.swing.JSeparator jsepContactNumber;
    private javax.swing.JSeparator jsepEmail;
    private javax.swing.JSeparator jsepIDNumber;
    private javax.swing.JSeparator jsepLastName;
    private javax.swing.JSeparator jsepMembershipID;
    private javax.swing.JSeparator jsepName;
    private javax.swing.JSeparator jsepPaymentReference;
    private javax.swing.JSeparator jsepRegistrationDate;
    private javax.swing.JScrollPane jspComponents;
    private javax.swing.JTextArea jtxaAddress;
    private javax.swing.JTextField jtxfEmail;
    private javax.swing.JTextField jtxfLastName;
    private javax.swing.JTextField jtxfMembershipID;
    private javax.swing.JTextField jtxfName;
    private javax.swing.JTextField jtxfPaymentReference;
    private javax.swing.JTextField jtxfRegistrationDate;
    // End of variables declaration//GEN-END:variables
}
