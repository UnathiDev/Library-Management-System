/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package libraryadmin;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.awt.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import librarymanagement.LibraryManagement;
import sqlconnect.SQLConnect;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Unathi Okhue
 */
public class jfrmMemberView extends javax.swing.JFrame {
    public jfrmMemberView() {
        initComponents();    
        populateBookList();
    }
    
    private static final String[] VALID_DOMAINS = {"skye.com", "gmail.com", "yahoo.com", "outlook.com", "icloud.com", "protonmail.com",
                                                    "zoho.com", "aol.com", "tutanota.com", "gmx.com", "fastmail.com", "mweb.co.za",
                                                    "telkomsa.net", "afrihost.com", "vodamail.co.za"};
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpnlBackground = new javax.swing.JPanel();
        jlblSubmit = new javax.swing.JLabel();
        jlblNewBook = new javax.swing.JLabel();
        jlblReturn = new javax.swing.JLabel();
        jspComponents = new javax.swing.JScrollPane();
        jpnlComponents = new javax.swing.JPanel();
        jtxfName = new javax.swing.JTextField();
        jlblPersonalDetails = new javax.swing.JLabel();
        jsepName = new javax.swing.JSeparator();
        jlblLastName = new javax.swing.JLabel();
        jsepLastName = new javax.swing.JSeparator();
        jsepIDNumber = new javax.swing.JSeparator();
        jlblIDNumber = new javax.swing.JLabel();
        jlblContactNumber = new javax.swing.JLabel();
        jftxfIDNumber = new javax.swing.JFormattedTextField();
        jtxfLastName = new javax.swing.JTextField();
        jftxfContactNumber = new javax.swing.JFormattedTextField();
        jsepContactNumber = new javax.swing.JSeparator();
        jsepEmail = new javax.swing.JSeparator();
        jlblEmail = new javax.swing.JLabel();
        jtxfEmail = new javax.swing.JTextField();
        jlblAddress = new javax.swing.JLabel();
        jsepAddress = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtxaAddress = new javax.swing.JTextArea();
        jlblName = new javax.swing.JLabel();
        jlblMembershipDetails = new javax.swing.JLabel();
        jsepMembershipID = new javax.swing.JSeparator();
        jtxfMembershipID = new javax.swing.JTextField();
        jlblMembershipID = new javax.swing.JLabel();
        jlblRegistrationDate = new javax.swing.JLabel();
        jtxfRegistrationDate = new javax.swing.JTextField();
        jsepRegistrationDate = new javax.swing.JSeparator();
        jlblMembershipType = new javax.swing.JLabel();
        jcomboMembershipType = new javax.swing.JComboBox<>();
        jlblMembershipStatus = new javax.swing.JLabel();
        jlblPaymeentDetails = new javax.swing.JLabel();
        jcomboPaymentMethod = new javax.swing.JComboBox<>();
        jlblPaymentMethod = new javax.swing.JLabel();
        jlblPaymentReference = new javax.swing.JLabel();
        jtxfPaymentReference = new javax.swing.JTextField();
        jsepPaymentReference = new javax.swing.JSeparator();
        jftxfAccountNumber = new javax.swing.JFormattedTextField();
        jlblAccountNumber = new javax.swing.JLabel();
        jsepAccountNumber = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        jlblName1 = new javax.swing.JLabel();
        jtxfSearch = new javax.swing.JTextField();
        jsepName1 = new javax.swing.JSeparator();
        jlblSearch = new javax.swing.JLabel();
        jlblName3 = new javax.swing.JLabel();
        jcomboTitles = new javax.swing.JComboBox<>();
        jlblDelete = new javax.swing.JLabel();
        jlblUpdate = new javax.swing.JLabel();
        jlblIssueBook = new javax.swing.JLabel();
        jlblReturnBook = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jpnlBackground.setBackground(new java.awt.Color(255, 255, 255));

        jlblSubmit.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblSubmit.setForeground(new java.awt.Color(51, 153, 255));
        jlblSubmit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblSubmit.setText("Submit");
        jlblSubmit.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblSubmit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblSubmitMousePressed(evt);
            }
        });

        jlblNewBook.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jlblNewBook.setForeground(new java.awt.Color(51, 153, 255));
        jlblNewBook.setText("View member");

        jlblReturn.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblReturn.setForeground(new java.awt.Color(51, 153, 255));
        jlblReturn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblReturn.setText("Retrun");
        jlblReturn.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblReturn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblReturnMousePressed(evt);
            }
        });

        jpnlComponents.setBackground(new java.awt.Color(255, 255, 255));

        jtxfName.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfName.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfName.setBorder(null);
        jtxfName.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jtxfName.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfNameMouseExited(evt);
            }
        });

        jlblPersonalDetails.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jlblPersonalDetails.setForeground(new java.awt.Color(51, 153, 255));
        jlblPersonalDetails.setText("Personal Details");
        jlblPersonalDetails.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));

        jsepName.setForeground(new java.awt.Color(51, 153, 255));

        jlblLastName.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblLastName.setForeground(new java.awt.Color(51, 153, 255));
        jlblLastName.setText("Last Name");

        jsepLastName.setForeground(new java.awt.Color(51, 153, 255));

        jsepIDNumber.setForeground(new java.awt.Color(51, 153, 255));

        jlblIDNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblIDNumber.setForeground(new java.awt.Color(51, 153, 255));
        jlblIDNumber.setText("ID Number");

        jlblContactNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblContactNumber.setForeground(new java.awt.Color(51, 153, 255));
        jlblContactNumber.setText("Contact Number");

        jftxfIDNumber.setBorder(null);
        try {
            jftxfIDNumber.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("######-###-###-#")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jftxfIDNumber.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jftxfIDNumber.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jftxfIDNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jftxfIDNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jftxfIDNumberActionPerformed(evt);
            }
        });

        jtxfLastName.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfLastName.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfLastName.setBorder(null);
        jtxfLastName.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jtxfLastName.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfLastNameMouseExited(evt);
            }
        });

        jftxfContactNumber.setBorder(null);
        try {
            jftxfContactNumber.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("+27-##-###-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jftxfContactNumber.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jftxfContactNumber.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jftxfContactNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N

        jsepContactNumber.setForeground(new java.awt.Color(51, 153, 255));

        jsepEmail.setForeground(new java.awt.Color(51, 153, 255));

        jlblEmail.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblEmail.setForeground(new java.awt.Color(51, 153, 255));
        jlblEmail.setText("Email");

        jtxfEmail.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfEmail.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfEmail.setBorder(null);
        jtxfEmail.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jtxfEmail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfEmailMouseExited(evt);
            }
        });

        jlblAddress.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblAddress.setForeground(new java.awt.Color(51, 153, 255));
        jlblAddress.setText("Address");

        jsepAddress.setForeground(new java.awt.Color(51, 153, 255));

        jtxaAddress.setColumns(20);
        jtxaAddress.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxaAddress.setRows(5);
        jtxaAddress.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jtxaAddress.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxaAddressMouseExited(evt);
            }
        });
        jScrollPane1.setViewportView(jtxaAddress);

        jlblName.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblName.setForeground(new java.awt.Color(51, 153, 255));
        jlblName.setText("Name");

        jlblMembershipDetails.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jlblMembershipDetails.setForeground(new java.awt.Color(51, 153, 255));
        jlblMembershipDetails.setText("Membership Details");
        jlblMembershipDetails.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));

        jsepMembershipID.setForeground(new java.awt.Color(51, 153, 255));

        jtxfMembershipID.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfMembershipID.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfMembershipID.setBorder(null);
        jtxfMembershipID.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        jlblMembershipID.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblMembershipID.setForeground(new java.awt.Color(51, 153, 255));
        jlblMembershipID.setText("Membership ID");

        jlblRegistrationDate.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblRegistrationDate.setForeground(new java.awt.Color(51, 153, 255));
        jlblRegistrationDate.setText("Date of Registration");

        jtxfRegistrationDate.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfRegistrationDate.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfRegistrationDate.setBorder(null);
        jtxfRegistrationDate.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        jsepRegistrationDate.setForeground(new java.awt.Color(51, 153, 255));

        jlblMembershipType.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblMembershipType.setForeground(new java.awt.Color(51, 153, 255));
        jlblMembershipType.setText("Membership Type");

        jcomboMembershipType.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboMembershipType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Student", "Adult", "Senior" }));

        jlblMembershipStatus.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblMembershipStatus.setForeground(new java.awt.Color(51, 153, 255));
        jlblMembershipStatus.setText("Membership Status:");

        jlblPaymeentDetails.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jlblPaymeentDetails.setForeground(new java.awt.Color(51, 153, 255));
        jlblPaymeentDetails.setText("Payment Details");
        jlblPaymeentDetails.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));

        jcomboPaymentMethod.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboPaymentMethod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Credit Card", "Debit Card", "PayPal", "Bank Transfer" }));

        jlblPaymentMethod.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblPaymentMethod.setForeground(new java.awt.Color(51, 153, 255));
        jlblPaymentMethod.setText("Payment Method");

        jlblPaymentReference.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblPaymentReference.setForeground(new java.awt.Color(51, 153, 255));
        jlblPaymentReference.setText("Payment Reference");

        jtxfPaymentReference.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfPaymentReference.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfPaymentReference.setBorder(null);
        jtxfPaymentReference.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        jsepPaymentReference.setForeground(new java.awt.Color(51, 153, 255));

        jftxfAccountNumber.setBorder(null);
        try {
            jftxfAccountNumber.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("######-###-###-#")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jftxfAccountNumber.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jftxfAccountNumber.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jftxfAccountNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N

        jlblAccountNumber.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblAccountNumber.setForeground(new java.awt.Color(51, 153, 255));
        jlblAccountNumber.setText("Account Number");

        jsepAccountNumber.setForeground(new java.awt.Color(51, 153, 255));

        javax.swing.GroupLayout jpnlComponentsLayout = new javax.swing.GroupLayout(jpnlComponents);
        jpnlComponents.setLayout(jpnlComponentsLayout);
        jpnlComponentsLayout.setHorizontalGroup(
            jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addComponent(jsepAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlblAccountNumber)
                                    .addComponent(jftxfAccountNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jsepAccountNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jsepPaymentReference, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
                                    .addComponent(jlblPaymentReference)
                                    .addComponent(jtxfPaymentReference)))
                            .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jsepName, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jtxfName, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jlblName))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jlblLastName)
                                        .addComponent(jsepLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jtxfLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(jlblIDNumber)
                                .addComponent(jftxfIDNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jsepIDNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jlblContactNumber)
                                        .addComponent(jsepContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jftxfContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jlblEmail)
                                        .addComponent(jsepEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jtxfEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(jlblAddress)
                                .addComponent(jlblPersonalDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jsepMembershipID, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jtxfMembershipID, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jlblRegistrationDate)
                                    .addComponent(jtxfRegistrationDate, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(12, 12, 12)
                                .addComponent(jcomboMembershipType, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addComponent(jlblMembershipID)
                                .addGap(146, 146, 146)
                                .addComponent(jlblMembershipType))
                            .addComponent(jlblMembershipDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 492, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlblMembershipStatus)
                            .addComponent(jlblPaymeentDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 492, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlblPaymentMethod)
                            .addComponent(jcomboPaymentMethod, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jsepRegistrationDate, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(174, Short.MAX_VALUE))))
        );
        jpnlComponentsLayout.setVerticalGroup(
            jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblPersonalDetails)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblLastName)
                    .addComponent(jlblName))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtxfName, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxfLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jsepName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jsepLastName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jlblIDNumber)
                .addGap(4, 4, 4)
                .addComponent(jftxfIDNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(jsepIDNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblContactNumber)
                    .addComponent(jlblEmail))
                .addGap(4, 4, 4)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jftxfContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxfEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jsepContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jsepEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addComponent(jlblAddress)
                .addGap(12, 12, 12)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jsepAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(jlblMembershipDetails)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblMembershipID)
                    .addComponent(jlblMembershipType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jcomboMembershipType, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addComponent(jtxfMembershipID, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jsepMembershipID, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblRegistrationDate)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtxfRegistrationDate, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jsepRegistrationDate, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jlblMembershipStatus)
                .addGap(55, 55, 55)
                .addComponent(jlblPaymeentDetails)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addComponent(jlblPaymentMethod)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jcomboPaymentMethod, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblAccountNumber)
                        .addGap(4, 4, 4)
                        .addComponent(jftxfAccountNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(jsepAccountNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addComponent(jlblPaymentReference)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtxfPaymentReference, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jsepPaymentReference, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jspComponents.setViewportView(jpnlComponents);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));

        jlblName1.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblName1.setForeground(new java.awt.Color(51, 153, 255));
        jlblName1.setText("Search (Name/ ID Number)");

        jtxfSearch.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfSearch.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfSearch.setBorder(null);
        jtxfSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfSearchMouseExited(evt);
            }
        });

        jsepName1.setForeground(new java.awt.Color(51, 153, 255));

        jlblSearch.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblSearch.setForeground(new java.awt.Color(51, 153, 255));
        jlblSearch.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblSearch.setText("Search");
        jlblSearch.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblSearchMousePressed(evt);
            }
        });

        jlblName3.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblName3.setForeground(new java.awt.Color(51, 153, 255));
        jlblName3.setText("Current Book");

        jcomboTitles.setEditable(true);
        jcomboTitles.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboTitles.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jcomboTitlesItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlblSearch, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jlblName3)
                                .addGap(148, 148, 148))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jsepName1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jtxfSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jlblName1)
                            .addComponent(jcomboTitles, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblName1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxfSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(jsepName1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblName3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jcomboTitles, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(66, Short.MAX_VALUE))
        );

        jlblDelete.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblDelete.setForeground(new java.awt.Color(51, 153, 255));
        jlblDelete.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblDelete.setText("Delete");
        jlblDelete.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblDelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblDeleteMousePressed(evt);
            }
        });

        jlblUpdate.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblUpdate.setForeground(new java.awt.Color(51, 153, 255));
        jlblUpdate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblUpdate.setText("Update");
        jlblUpdate.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblUpdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblUpdateMousePressed(evt);
            }
        });

        jlblIssueBook.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblIssueBook.setForeground(new java.awt.Color(51, 153, 255));
        jlblIssueBook.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblIssueBook.setText("Issue Book");
        jlblIssueBook.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblIssueBook.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblIssueBookMousePressed(evt);
            }
        });

        jlblReturnBook.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblReturnBook.setForeground(new java.awt.Color(51, 153, 255));
        jlblReturnBook.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblReturnBook.setText("Return Book");
        jlblReturnBook.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblReturnBook.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblReturnBookMousePressed(evt);
            }
        });

        javax.swing.GroupLayout jpnlBackgroundLayout = new javax.swing.GroupLayout(jpnlBackground);
        jpnlBackground.setLayout(jpnlBackgroundLayout);
        jpnlBackgroundLayout.setHorizontalGroup(
            jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                        .addComponent(jlblNewBook)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                        .addComponent(jspComponents, javax.swing.GroupLayout.PREFERRED_SIZE, 633, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnlBackgroundLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                                        .addComponent(jlblIssueBook, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jlblReturnBook, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnlBackgroundLayout.createSequentialGroup()
                                            .addComponent(jlblReturn, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jlblDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnlBackgroundLayout.createSequentialGroup()
                                            .addComponent(jlblUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jlblSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))))))))
                .addContainerGap())
        );
        jpnlBackgroundLayout.setVerticalGroup(
            jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblNewBook)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlblIssueBook, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlblReturnBook, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlblDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlblReturn, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlblSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlblUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jspComponents, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpnlBackground, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpnlBackground, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jlblSubmitMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblSubmitMousePressed
        String memberFullName, memberIDNumber, memberContactNumber, memberEmail, memberAddress;
        String membershipID, membershipType, strRegistrationDate, membershipStatus;
        String paymentMethod, accountNumber, paymentReference;
        String memberPaymentQuery, memberQuery, membershipQuery, memberLoginQuery;

        memberFullName = jtxfName.getText() + " " + jtxfLastName.getText();
        memberIDNumber = jftxfIDNumber.getText();
        memberContactNumber = jftxfContactNumber.getText();
        memberEmail = jtxfEmail.getText();
        memberAddress = jtxaAddress.getText();
        
        membershipID = jtxfMembershipID.getText();
        membershipType = (String) jcomboMembershipType.getSelectedItem();
        strRegistrationDate = jtxfRegistrationDate.getText();
        membershipStatus = "ACTIVE";
        
        paymentMethod = (String) jcomboPaymentMethod.getSelectedItem();
        accountNumber = jftxfAccountNumber.getText();
        paymentReference = jtxfPaymentReference.getText();
        

        if (memberFullName == null || memberIDNumber == null || memberContactNumber == null ||
            memberEmail == null || memberAddress == null ||membershipID == null || membershipType == null || 
            strRegistrationDate == null || accountNumber == null || paymentReference == null) {
            JOptionPane.showMessageDialog(null, "Missing fields.\nPlease makes sure no fields are left blank.", "Request unsuccessfull", JOptionPane.ERROR_MESSAGE);
        } else if (!isValidDomain(memberEmail)){
            JOptionPane.showMessageDialog(null, "Invalid email provided.\nPlease check the email field.", "Request unsuccessfull", JOptionPane.ERROR_MESSAGE);
        } else if(!memberAddress.matches("[a-zA-Z0-9 ]+")) {
            JOptionPane.showMessageDialog(null, "Use of illegal characters found.\nPlease check all fields.", "Request unsuccessfull", JOptionPane.ERROR_MESSAGE);
        } else{
            try {
                memberPaymentQuery = "UPDATE tblMemberPayment SET PaymentMethod = '" + paymentMethod + "', AccountNumber = '" + accountNumber + "' WHERE MemberID = '" + membershipID + "'";
                memberQuery = "UPDATE tblMembers SET Name = '" + memberFullName + "', Address = '" + memberAddress + "', ContactNumber = '" + memberContactNumber + "', Email = '" + memberEmail + "' WHERE MemberID = '" + membershipID + "'";
                membershipQuery = "UPDATE tblMembership SET MembershipStatus = '" + membershipStatus + "', MemberType = '" + membershipType + "' WHERE MemberID = '" + membershipID + "'";
                memberLoginQuery = "UPDATE tblAdmin SET Blocked = false WHERE Username = '" + membershipID + "'";
                
                Connection connect = SQLConnect.connect();
                PreparedStatement statementPayment = connect.prepareStatement(memberPaymentQuery);
                PreparedStatement statementMembers = connect.prepareStatement(memberQuery);
                PreparedStatement statementMembership = connect.prepareStatement(membershipQuery);
                PreparedStatement statementAdmin = connect.prepareStatement(memberLoginQuery);
                
                int paymentRows = statementPayment.executeUpdate();
                int membersRows = statementMembers.executeUpdate();
                int membershipRows = statementMembership.executeUpdate();
                int adminRows = statementAdmin.executeUpdate();

                if (paymentRows > 0 && membersRows > 0 && membershipRows > 0 && adminRows > 0) {
                    JOptionPane.showMessageDialog(null, "Information for " + memberFullName + "\n" + membershipID + " has been updated.", "Operation successfull", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "ERROR! Unable to update member info.\nPlease check all info provided and try again", "Operation failed", JOptionPane.ERROR_MESSAGE);
                }
                connect.close();
                statementPayment.close();
                statementMembers.close();
                statementMembership.close();
                statementAdmin.close();
            } catch (HeadlessException | SQLException e) {
                JOptionPane.showMessageDialog(null, "Unable to connect to database at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
                System.out.println(e);
            }catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Unable to connect to perform operation at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_jlblSubmitMousePressed

    private void jlblSearchMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblSearchMousePressed
        String searchStr = jtxfSearch.getText(), membershipQuery, membersQuery, adminQuery, loanQuery;
        String memberID, memberName, memberAddress, memberContact, memberEmail, memberIDNumber, 
                membershipStatus, memberType, registrationDate, paymentMethod, accountNumber;
        
        try {
            membersQuery = "SELECT * FROM tblMembers WHERE MemberID = '" + searchStr + "' OR Name LIKE '%" + searchStr + "%'";
            Connection connect = SQLConnect.connect();
            PreparedStatement statement = connect.prepareStatement(membersQuery);
            ResultSet setMembers = statement.executeQuery();
            
            if (setMembers.next()) {
                memberID = setMembers.getString("MemberID");
                jtxfMembershipID.setText(memberID);
                
                memberName = setMembers.getString("Name");
                String[] nameSplit = memberName.split(" ");
                jtxfName.setText(nameSplit[0]);
                jtxfLastName.setText(nameSplit[1]);
                
                memberAddress = setMembers.getString("Address");
                jtxaAddress.setText(memberAddress);
                
                memberContact = setMembers.getString("ContactNumber");
                jftxfContactNumber.setText(memberContact);
                
                memberEmail = setMembers.getString("Email");
                jtxfEmail.setText(memberEmail);
                
                memberIDNumber = setMembers.getString("IDNumber");
                jftxfIDNumber.setText(memberIDNumber);
                
                
                membershipQuery =   "SELECT tblMembership.MembershipStatus, tblMembership.MemberType, tblMembership.RegistrationDate, \n" +
                                    "tblMemberPayment.PaymentMethod, tblMemberPayment.AccountNumber, tblMemberPayment.PaymentReference, \n" +
                                    "tblAdmin.\"BLOCKED\" \n" +
                                    "FROM tblMembership\n" +
                                    "INNER JOIN tblMemberPayment ON tblMembership.MemberID = tblMemberPayment.MemberID\n" +
                                    "INNER JOIN tblAdmin ON tblMemberPayment.MemberID = tblAdmin.USERNAME\n" +
                                    "WHERE tblMembership.MemberID = '" + memberID + "'";
                PreparedStatement membershipStatement = connect.prepareStatement(membershipQuery);
                ResultSet setMembership = membershipStatement.executeQuery();
                
                if (setMembership.next()) {
                    membershipStatus = setMembership.getString("MembershipStatus");
                    jlblMembershipStatus.setText("Membership Status: " + membershipStatus);
                    
                    memberType = setMembership.getString("MemberType");
                    jcomboMembershipType.setSelectedItem(memberType);
                    
                    registrationDate = setMembership.getString("RegistrationDate");
                    jtxfRegistrationDate.setText(registrationDate);
                    
                    paymentMethod = setMembership.getString("PaymentMethod");
                    jcomboPaymentMethod.setSelectedItem(paymentMethod);
                    
                    accountNumber = setMembership.getString("AccountNumber");
                    jftxfAccountNumber.setText(accountNumber);
                    
                    jtxfPaymentReference.setText(memberID);
                }
                membershipStatement.close();
                setMembership.close();
                componentsStatus(false);
            } else {
                JOptionPane.showMessageDialog(null, "No record found for " + searchStr + ".", "Operation failed", JOptionPane.ERROR_MESSAGE);
            }
            
            loanQuery = "SELECT * FROM tblLoans WHERE MemberID = '" + jtxfMembershipID.getText() + "'";
            
            PreparedStatement loanStatement = connect.prepareStatement(loanQuery);
            ResultSet setLoan = loanStatement.executeQuery();
            
            String bookHolding;
            Date issueDate, returnDate;
            double fineAmount;
            
            if (setLoan.next()) {
                bookHolding = setLoan.getString("BookISBN");
                jcomboTitles.setSelectedItem(bookHolding);
                issueDate = setLoan.getDate("IssueDate");
                returnDate = setLoan.getDate("ReturnDate");
                fineAmount = setLoan.getDouble("FineAmount");
            }
            
            loanStatement.close();
            setLoan.close();
            
            connect.close();
            statement.close();
            setMembers.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Unable to connect to database at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unable to perform operation at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }
    }//GEN-LAST:event_jlblSearchMousePressed

    private void jlblReturnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblReturnMousePressed
        LibraryManagement library = new LibraryManagement();
        library.memberMenu = new jfrmMemberMenu();
        library.memberMenu.setLocationRelativeTo(null);
        library.memberMenu.setVisible(true);
        dispose();
    }//GEN-LAST:event_jlblReturnMousePressed

    private void jftxfIDNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jftxfIDNumberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jftxfIDNumberActionPerformed

    private void jtxfEmailMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfEmailMouseExited
        String inEmail = jtxfEmail.getText();
        if (isValidDomain(inEmail)) {
            jsepEmail.setForeground(new Color(51,153,255));
        } else {
            jsepEmail.setForeground(new Color(255,0,0));
        }
    }//GEN-LAST:event_jtxfEmailMouseExited

    private void jtxfNameMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfNameMouseExited
        String testName = jtxfName.getText();
        if (validString(testName)) {
            jsepName.setForeground(new Color(51,153,255));
        } else {
            jsepName.setForeground(new Color(255,0,0));
        }
    }//GEN-LAST:event_jtxfNameMouseExited

    private void jtxfLastNameMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfLastNameMouseExited
        String testLastName = jtxfLastName.getText();
        if (validString(testLastName)) {
            jsepLastName.setForeground(new Color(51,153,255));
        } else {
            jsepLastName.setForeground(new Color(255,0,0));
        }
    }//GEN-LAST:event_jtxfLastNameMouseExited

    private void jtxaAddressMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxaAddressMouseExited
        String testAddress = jtxaAddress.getText();
        if (testAddress.matches("[a-zA-Z0-9 ]+")) {
            jsepAddress.setForeground(new Color(51,153,255));
        } else {
            jsepAddress.setForeground(new Color(255,0,0));
        }
    }//GEN-LAST:event_jtxaAddressMouseExited

    private void jtxfSearchMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfSearchMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxfSearchMouseExited

    private void jlblDeleteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblDeleteMousePressed
        String memberPaymentQuery, memberQuery, membershipQuery, memberLoginQuery, membershipID;
        membershipID = jtxfMembershipID.getText();
        
        memberPaymentQuery = "DELETE FROM tblMemberPayment WHERE MemberID = '" + membershipID + "'";
        memberQuery = "DELETE FROM tblMembers WHERE MemberID = '" + membershipID + "'";
        membershipQuery = "DELETE FROM tblMembership WHERE MemberID = '" + membershipID + "'";
        memberLoginQuery = "DELETE FROM tblAdmin WHERE Username = '" + membershipID + "'";
        
        try {
            int option = JOptionPane.showConfirmDialog(null, "Are you sure you would like to proceed with this action?\nThe effects are irreversable.", "Confirm Action", JOptionPane.YES_NO_OPTION);
            
            if (option == JOptionPane.YES_OPTION) {
                Connection connect = SQLConnect.connect();
                PreparedStatement statementPayment = connect.prepareStatement(memberPaymentQuery);
                PreparedStatement statementMember = connect.prepareStatement(memberQuery);
                PreparedStatement statementMembership = connect.prepareStatement(membershipQuery);
                PreparedStatement statementLogin = connect.prepareStatement(memberLoginQuery);
                
                int rowPayment = statementPayment.executeUpdate();
                int rowMember = statementMember.executeUpdate();
                int rowMembership = statementMembership.executeUpdate();
                int rowLogin = statementLogin.executeUpdate();
                
                if (rowPayment > 0 || rowMember > 0 || rowMembership > 0 || rowLogin > 0) {
                    JOptionPane.showMessageDialog(null, "Mmeber has been removed.", "Operation successfull", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "ERROR! Unable to delete member info.\nPlease check all info provided and try again", "Operation failed", JOptionPane.ERROR_MESSAGE);
                }
                
                statementPayment.close();
                statementMember.close();
                statementMembership.close();
                statementLogin.close();
                connect.close();
                Thread.sleep(500);
                
                LibraryManagement library = new LibraryManagement(); 
                library.memberMenu = new jfrmMemberMenu();
                library.memberMenu.setLocationRelativeTo(null);
                library.memberMenu.setVisible(true);
                dispose();
            } else {
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Unable to connect to database at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unable to connect to perform operation at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }
    }//GEN-LAST:event_jlblDeleteMousePressed

    private void jlblUpdateMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblUpdateMousePressed
        int option = JOptionPane.showConfirmDialog(null, "Are you sure you would like to proceed with this action?", "Confirm Action", JOptionPane.YES_NO_CANCEL_OPTION);
        
        if (option == JOptionPane.YES_OPTION) {
            componentsStatus(true);
        } else {
        }
    }//GEN-LAST:event_jlblUpdateMousePressed

    private void jlblIssueBookMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblIssueBookMousePressed
        String bookTitle = (String) jcomboTitles.getSelectedItem(), memberID = jtxfMembershipID.getText(), ISBN;
        
        try {
            String query = "SELECT ISBN FROM tblBooks WHERE Title = ?";
            Connection connect = SQLConnect.connect();
            PreparedStatement statement = connect.prepareStatement(query);
            statement.setString(1, bookTitle); // Set the parameter value

            ResultSet set = statement.executeQuery();
            if (set.next()) { // Check if the result set is not empty
                ISBN = set.getString("ISBN");

                String query3 = "UPDATE tblLoans SET " +
                        "BookISBN = ?, " + // Use a parameter instead of concatenation
                        "IssueDate = CURRENT_DATE, " +
                        "FineAmount = (SELECT SellingPrice / 12 FROM tblBooks WHERE ISBN = ?) " // Use a parameter instead of concatenation
                        + "WHERE MemberID = ?"; // Use a parameter instead of concatenation

                PreparedStatement statementLoan = connect.prepareStatement(query3);
                statementLoan.setString(1, ISBN); // Set the parameter value
                statementLoan.setString(2, ISBN); // Set the parameter value
                statementLoan.setString(3, jtxfMembershipID.getText()); // Set the parameter value

                int loanRow = statementLoan.executeUpdate();

                if (loanRow > 0) {
                    JOptionPane.showMessageDialog(null, "Update for member " + jtxfMembershipID.getText() + " successful.", "", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Update unsuccessful\nContact I.T. support for further assistance.", "", JOptionPane.ERROR_MESSAGE);
                }
                statementLoan.close();
            } else {
                JOptionPane.showMessageDialog(null, "Book title not found.", "", JOptionPane.ERROR_MESSAGE);
            }
            connect.close();
            statement.close();
            set.close();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error in issuing book.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error in operation.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }
    }//GEN-LAST:event_jlblIssueBookMousePressed

    private void jlblReturnBookMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblReturnBookMousePressed
        String memberID = jtxfMembershipID.getText();
        
        try {
            Connection connect = SQLConnect.connect();
       
            String query3 = "UPDATE tblLoans SET " +
                    "BookISBN = NULL, " + // Use a parameter instead of concatenation
                    "IssueDate = NULL, " +
                    "FineAmount = 0 " // Use a parameter instead of concatenation
                    + "WHERE MemberID = ?"; // Use a parameter instead of concatenation

            PreparedStatement statementLoan = connect.prepareStatement(query3);
            statementLoan.setString(1, memberID); // Set the parameter value

            int loanRow = statementLoan.executeUpdate();

            if (loanRow > 0) {
                JOptionPane.showMessageDialog(null, "Update for member " + memberID + " successful.", "", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Update unsuccessful\nContact I.T. support for further assistance.", "", JOptionPane.ERROR_MESSAGE);
            }
            statementLoan.close();
            
            connect.close();

            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error in returning book.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error in operation.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }
    }//GEN-LAST:event_jlblReturnBookMousePressed

    private void jcomboTitlesItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jcomboTitlesItemStateChanged
        
    }//GEN-LAST:event_jcomboTitlesItemStateChanged

    public void componentsStatus(boolean enabled){
        jtxfMembershipID.setEnabled(enabled);
        jtxfName.setEnabled(enabled);
        jtxfLastName.setEnabled(enabled);
        jtxaAddress.setEnabled(enabled);
        jftxfContactNumber.setEnabled(enabled);
        jtxfEmail.setEnabled(enabled);
        jftxfIDNumber.setEnabled(false);
        jcomboMembershipType.setEnabled(enabled);
        jtxfRegistrationDate.setEnabled(false);
        jcomboPaymentMethod.setEnabled(enabled);
        jftxfAccountNumber.setEnabled(enabled);
        jtxfPaymentReference.setEnabled(false);
    }
    
    public static boolean isValidDomain(String email) {
        String[] parts = email.split("@");
        if (parts.length != 2) {
            return false;
        }

        String domain = parts[1];
        for (String validDomain : VALID_DOMAINS) {
            if (domain.equals(validDomain)) {
                return true;
            }
        }
        return false;
    }
    
    boolean validString(String inStr){
        return inStr.matches("[a-zA-Z]+");
    }
    
    public static String encrypt(String plainText) {
        StringBuilder encryptedText = new StringBuilder();
        int shift = 4;
        for (char c : plainText.toCharArray()) {
            if (Character.isLetter(c)){
                char shiftedChar = (char) (c + shift);
                if (Character.isUpperCase(c) && shiftedChar > 'Z') {
                    shiftedChar = (char) ('A' + shiftedChar - 'Z' - 1);
                } else if (Character.isLowerCase(c) && shiftedChar > 'z') {
                    shiftedChar = (char) ('a' + shiftedChar - 'z' - 1);
                }
                encryptedText.append(shiftedChar);
            } else {
                encryptedText.append(c);
            }
        }
        return encryptedText.toString();
    }
    
    void populateBookList(){
        try {
            String query = "SELECT * FROM tblBooks ORDER BY Title";
            Connection connect = SQLConnect.connect();
            PreparedStatement statement = connect.prepareStatement(query);
            ResultSet set = statement.executeQuery();
            
            while(set.next()){
                jcomboTitles.addItem(set.getString(2));
            }
            
            connect.close();
            statement.close();
            set.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error in collecting book list.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error in operation.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(jfrmMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(jfrmMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(jfrmMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(jfrmMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new jfrmMember().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> jcomboMembershipType;
    private javax.swing.JComboBox<String> jcomboPaymentMethod;
    private javax.swing.JComboBox<String> jcomboTitles;
    private javax.swing.JFormattedTextField jftxfAccountNumber;
    private javax.swing.JFormattedTextField jftxfContactNumber;
    private javax.swing.JFormattedTextField jftxfIDNumber;
    private javax.swing.JLabel jlblAccountNumber;
    private javax.swing.JLabel jlblAddress;
    private javax.swing.JLabel jlblContactNumber;
    private javax.swing.JLabel jlblDelete;
    private javax.swing.JLabel jlblEmail;
    private javax.swing.JLabel jlblIDNumber;
    private javax.swing.JLabel jlblIssueBook;
    private javax.swing.JLabel jlblLastName;
    private javax.swing.JLabel jlblMembershipDetails;
    private javax.swing.JLabel jlblMembershipID;
    private javax.swing.JLabel jlblMembershipStatus;
    private javax.swing.JLabel jlblMembershipType;
    private javax.swing.JLabel jlblName;
    private javax.swing.JLabel jlblName1;
    private javax.swing.JLabel jlblName2;
    private javax.swing.JLabel jlblName3;
    private javax.swing.JLabel jlblNewBook;
    private javax.swing.JLabel jlblPaymeentDetails;
    private javax.swing.JLabel jlblPaymentMethod;
    private javax.swing.JLabel jlblPaymentReference;
    private javax.swing.JLabel jlblPersonalDetails;
    private javax.swing.JLabel jlblRegistrationDate;
    private javax.swing.JLabel jlblReturn;
    private javax.swing.JLabel jlblReturnBook;
    private javax.swing.JLabel jlblSearch;
    private javax.swing.JLabel jlblSearch1;
    private javax.swing.JLabel jlblSubmit;
    private javax.swing.JLabel jlblUpdate;
    private javax.swing.JPanel jpnlBackground;
    private javax.swing.JPanel jpnlComponents;
    private javax.swing.JSeparator jsepAccountNumber;
    private javax.swing.JSeparator jsepAddress;
    private javax.swing.JSeparator jsepContactNumber;
    private javax.swing.JSeparator jsepEmail;
    private javax.swing.JSeparator jsepIDNumber;
    private javax.swing.JSeparator jsepLastName;
    private javax.swing.JSeparator jsepMembershipID;
    private javax.swing.JSeparator jsepName;
    private javax.swing.JSeparator jsepName1;
    private javax.swing.JSeparator jsepName2;
    private javax.swing.JSeparator jsepPaymentReference;
    private javax.swing.JSeparator jsepRegistrationDate;
    private javax.swing.JScrollPane jspComponents;
    private javax.swing.JTextArea jtxaAddress;
    private javax.swing.JTextField jtxfEmail;
    private javax.swing.JTextField jtxfLastName;
    private javax.swing.JTextField jtxfMembershipID;
    private javax.swing.JTextField jtxfName;
    private javax.swing.JTextField jtxfPaymentReference;
    private javax.swing.JTextField jtxfRegistrationDate;
    private javax.swing.JTextField jtxfSearch;
    private javax.swing.JTextField jtxfSearch1;
    // End of variables declaration//GEN-END:variables
}
