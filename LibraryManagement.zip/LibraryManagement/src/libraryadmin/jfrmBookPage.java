/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package libraryadmin;

import java.awt.*;
import java.sql.*;
import javax.swing.JOptionPane;
import librarymanagement.LibraryManagement;
import sqlconnect.SQLConnect;

/**
 *
 * @author Unathi Okhue
 */
public class jfrmBookPage extends javax.swing.JFrame {

    public jfrmBookPage() {
        initComponents();
        try {
            String query = "SELECT * FROM tblBooks ORDER BY Title";
            Connection connect = SQLConnect.connect();
            PreparedStatement statement = connect.prepareStatement(query);
            ResultSet set = statement.executeQuery();
            
            while(set.next()){
                jcomboTitles.addItem(set.getString(2));
            }
            
            connect.close();
            statement.close();
            set.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error in collecting book list.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error in operation.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }
    }
    
    String[] publishers = {
        "Skye Publishing", "Ingram Content Group",
        "Baker & Taylor", "AuthorHouse",
        "The Bonoi Group", "Independent Publishers Group (IPG)",
        "Consortium Book Sales & Distribution", "Perseus Books Group",
        "Publishers Group West (PGW)", "Hachette Book Group",
        "Simon & Schuster", "HarperCollins",
        "Random House", "Bookazine",
        "Midpoint Trade Books", "Greenleaf Book Group",
        "Book Distribution Services", "Trafalgar Square Publishing",
        "Chicago Distribution Center", "National Book Network (NBN)",
        "Small Press Distribution (SPD)"
    };
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jpnlComponents = new javax.swing.JPanel();
        jtxfTitle = new javax.swing.JTextField();
        jlblTitle = new javax.swing.JLabel();
        jsepTitle = new javax.swing.JSeparator();
        jlblISBN = new javax.swing.JLabel();
        jsepISBN = new javax.swing.JSeparator();
        jsepAuthor = new javax.swing.JSeparator();
        jtxfAuthor = new javax.swing.JTextField();
        jlblAuthor = new javax.swing.JLabel();
        jlblPublisher = new javax.swing.JLabel();
        jcomboPublisher = new javax.swing.JComboBox<>();
        jcomboPublicationYear = new javax.swing.JComboBox<>();
        jlblPublicationYear = new javax.swing.JLabel();
        jcomboGenre = new javax.swing.JComboBox<>();
        jlblGenre = new javax.swing.JLabel();
        jlblQuantity = new javax.swing.JLabel();
        jlblRent = new javax.swing.JLabel();
        jsepRent = new javax.swing.JSeparator();
        jsepSellingPrice = new javax.swing.JSeparator();
        jlblSelling = new javax.swing.JLabel();
        jftxfISBN = new javax.swing.JFormattedTextField();
        jsepAuthor1 = new javax.swing.JSeparator();
        jtxfEstimatedRent = new javax.swing.JTextField();
        jtxfQuantity = new javax.swing.JTextField();
        jtxfEstimatedSelling = new javax.swing.JTextField();
        jlblNewBook = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jlblSubmitChanges = new javax.swing.JLabel();
        jlblRemove = new javax.swing.JLabel();
        jlblUpdate = new javax.swing.JLabel();
        jlblTitle1 = new javax.swing.JLabel();
        jcomboTitles = new javax.swing.JComboBox<>();
        jlblReturn = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jpnlComponents.setBackground(new java.awt.Color(255, 255, 255));

        jtxfTitle.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfTitle.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfTitle.setBorder(null);
        jtxfTitle.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jtxfTitle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfTitleMouseExited(evt);
            }
        });

        jlblTitle.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblTitle.setForeground(new java.awt.Color(51, 153, 255));
        jlblTitle.setText("Title");

        jsepTitle.setForeground(new java.awt.Color(51, 153, 255));

        jlblISBN.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblISBN.setForeground(new java.awt.Color(51, 153, 255));
        jlblISBN.setText("ISBN");

        jsepISBN.setForeground(new java.awt.Color(51, 153, 255));

        jsepAuthor.setForeground(new java.awt.Color(51, 153, 255));

        jtxfAuthor.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfAuthor.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfAuthor.setBorder(null);
        jtxfAuthor.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jtxfAuthor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfAuthorMouseExited(evt);
            }
        });
        jtxfAuthor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxfAuthorActionPerformed(evt);
            }
        });

        jlblAuthor.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblAuthor.setForeground(new java.awt.Color(51, 153, 255));
        jlblAuthor.setText("Author (Full Name)");

        jlblPublisher.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblPublisher.setForeground(new java.awt.Color(51, 153, 255));
        jlblPublisher.setText("Publisher");

        jcomboPublisher.setEditable(true);
        jcomboPublisher.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboPublisher.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Skye Publishing", "Ingram Content Group", "Baker & Taylor", "AuthorHouse", "The Bonoi Group", "Independent Publishers Group (IPG)", "Consortium Book Sales & Distribution", "Perseus Books Group", "Publishers Group West (PGW)", "Hachette Book Group", "Simon & Schuster", "HarperCollins", "Random House", "Bookazine", "Midpoint Trade Books", "Greenleaf Book Group", "Book Distribution Services", "Trafalgar Square Publishing", "Chicago Distribution Center", "National Book Network (NBN)", "Small Press Distribution (SPD)" }));
        jcomboPublisher.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jcomboPublisherItemStateChanged(evt);
            }
        });

        jcomboPublicationYear.setEditable(true);
        jcomboPublicationYear.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboPublicationYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "1927", "1928", "1929", "1930", "1931", "1932", "1933", "1934", "1935", "1936", "1937", "1938", "1939", "1940", "1941", "1942", "1943", "1944", "1945", "1946", "1947", "1948", "1949", "1950", "1951", "1952", "1953", "1954", "1955", "1956", "1957", "1958", "1959", "1960", "1961", "1962", "1963", "1964", "1965", "1966", "1967", "1968", "1969", "1970", "1971", "1972", "1973", "1974", "1975", "1976", "1977", "1978", "1979", "1980", "1981", "1982", "1983", "1984", "1985", "1986", "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027" }));

        jlblPublicationYear.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblPublicationYear.setForeground(new java.awt.Color(51, 153, 255));
        jlblPublicationYear.setText("Publication Year");

        jcomboGenre.setEditable(true);
        jcomboGenre.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboGenre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fantasy", "Science Fiction", "Dystopian", "Action & Adventure", "Mystery", "Horror", "Thriller & Suspense", "Romance", "Historical Fiction", "Young Adult (YA)", "Children's", "Women's Fiction", "Contemporary Fiction", "Literary Fiction", "Graphic Novel", "Short Story", "Memoir & Autobiography", "Biography", "Food & Drink", "Art & Photography", "Self-Help", "History", "Travel", "True Crime", "Humor", "Essays", "Guide/How-to", "Religion & Spirituality", "Humanities   1  & Social Sciences", "Parenting & Families", "Science & Technology" }));

        jlblGenre.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblGenre.setForeground(new java.awt.Color(51, 153, 255));
        jlblGenre.setText("Genre");

        jlblQuantity.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblQuantity.setForeground(new java.awt.Color(51, 153, 255));
        jlblQuantity.setText("Quantity");

        jlblRent.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblRent.setForeground(new java.awt.Color(51, 153, 255));
        jlblRent.setText("Estimated Rent Price");

        jsepRent.setForeground(new java.awt.Color(51, 153, 255));

        jsepSellingPrice.setForeground(new java.awt.Color(51, 153, 255));

        jlblSelling.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblSelling.setForeground(new java.awt.Color(51, 153, 255));
        jlblSelling.setText("Estimated Selling Price");

        jftxfISBN.setBorder(null);
        try {
            jftxfISBN.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####-#-##-######-#")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jftxfISBN.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jftxfISBN.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jftxfISBN.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N

        jsepAuthor1.setForeground(new java.awt.Color(51, 153, 255));

        jtxfEstimatedRent.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfEstimatedRent.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfEstimatedRent.setBorder(null);
        jtxfEstimatedRent.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jtxfEstimatedRent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfEstimatedRentMouseExited(evt);
            }
        });

        jtxfQuantity.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfQuantity.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfQuantity.setBorder(null);
        jtxfQuantity.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jtxfQuantity.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfQuantityMouseExited(evt);
            }
        });

        jtxfEstimatedSelling.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfEstimatedSelling.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfEstimatedSelling.setBorder(null);
        jtxfEstimatedSelling.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        jtxfEstimatedSelling.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfEstimatedSellingMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jpnlComponentsLayout = new javax.swing.GroupLayout(jpnlComponents);
        jpnlComponents.setLayout(jpnlComponentsLayout);
        jpnlComponentsLayout.setHorizontalGroup(
            jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jsepAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jtxfAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jlblGenre)
                            .addComponent(jcomboGenre, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlblAuthor))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlblPublisher)
                                    .addComponent(jcomboPublisher, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlblPublicationYear)
                                    .addComponent(jcomboPublicationYear, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(21, Short.MAX_VALUE))
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jtxfQuantity, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE)
                                    .addComponent(jlblQuantity, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jsepAuthor1, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlblTitle)
                                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jsepTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jtxfTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jlblISBN)
                                    .addComponent(jsepISBN)
                                    .addComponent(jftxfISBN, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)))
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addComponent(jsepRent, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jsepSellingPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jpnlComponentsLayout.createSequentialGroup()
                                    .addComponent(jtxfEstimatedRent, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jtxfEstimatedSelling))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jpnlComponentsLayout.createSequentialGroup()
                                    .addComponent(jlblRent)
                                    .addGap(30, 30, 30)
                                    .addComponent(jlblSelling))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jpnlComponentsLayout.setVerticalGroup(
            jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlblTitle, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jlblISBN))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jftxfISBN)
                    .addComponent(jtxfTitle, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE))
                .addGap(4, 4, 4)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jsepTitle, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jsepISBN, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlblAuthor, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jlblPublisher)
                        .addComponent(jlblPublicationYear)))
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jtxfAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jsepAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jcomboPublicationYear, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                            .addComponent(jcomboPublisher))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblGenre)
                    .addComponent(jlblQuantity))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jcomboGenre, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxfQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jsepAuthor1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 109, Short.MAX_VALUE)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblRent)
                    .addComponent(jlblSelling))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtxfEstimatedRent, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxfEstimatedSelling, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jsepRent, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jsepSellingPrice, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7))
        );

        jlblNewBook.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jlblNewBook.setForeground(new java.awt.Color(51, 153, 255));
        jlblNewBook.setText("Search book");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));

        jlblSubmitChanges.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblSubmitChanges.setForeground(new java.awt.Color(51, 153, 255));
        jlblSubmitChanges.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblSubmitChanges.setText("Submit Changes");
        jlblSubmitChanges.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblSubmitChanges.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblSubmitChangesMousePressed(evt);
            }
        });

        jlblRemove.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblRemove.setForeground(new java.awt.Color(51, 153, 255));
        jlblRemove.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblRemove.setText("Remove");
        jlblRemove.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblRemove.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblRemoveMousePressed(evt);
            }
        });

        jlblUpdate.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblUpdate.setForeground(new java.awt.Color(51, 153, 255));
        jlblUpdate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblUpdate.setText("Update");
        jlblUpdate.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblUpdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblUpdateMousePressed(evt);
            }
        });

        jlblTitle1.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblTitle1.setForeground(new java.awt.Color(51, 153, 255));
        jlblTitle1.setText("Search by Title");

        jcomboTitles.setEditable(true);
        jcomboTitles.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboTitles.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jcomboTitlesItemStateChanged(evt);
            }
        });

        jlblReturn.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblReturn.setForeground(new java.awt.Color(51, 153, 255));
        jlblReturn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblReturn.setText("Retrun");
        jlblReturn.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblReturn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblReturnMousePressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jlblRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlblUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jlblSubmitChanges, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblReturn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jlblTitle1)
                        .addGap(143, 143, 143))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jcomboTitles, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jlblTitle1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jcomboTitles, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 314, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblReturn, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblSubmitChanges, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jpnlComponents, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jlblNewBook)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jlblNewBook)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnlComponents, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 516, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jlblSubmitChangesMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblSubmitChangesMousePressed
        String query, title, bookISBN, bookTitle, bookAuthor, publicationYear, bookPublisher, publicationGenre;
        int quantity;
        double sellingPrice;
        
        
        try {
            bookTitle = jtxfTitle.getText();
            bookISBN = jftxfISBN.getText();
            bookAuthor = jtxfAuthor.getText();
            bookPublisher = (String) jcomboPublisher.getSelectedItem();
            publicationYear = (String) jcomboPublicationYear.getSelectedItem();
            publicationGenre = (String) jcomboGenre.getSelectedItem();
            quantity =  Integer.parseInt(jtxfQuantity.getText());
            sellingPrice = Double.parseDouble(jtxfEstimatedSelling.getText());
             
            query = "UPDATE tblBooks SET Title = ?, Author = ?, Publisher = ?, Genre = ?, Quantity = ?, SellingPrice = ? WHERE ISBN = '" + bookISBN + "'";
            Connection connect = SQLConnect.connect();
            PreparedStatement statement = connect.prepareStatement(query);
            statement.setString(1, bookTitle);
            statement.setString(2, bookAuthor);
            statement.setString(3, bookPublisher);
            statement.setString(4, publicationGenre);
            statement.setInt(5, quantity);
            statement.setDouble(6, sellingPrice);
            
            int rowsInserted = statement.executeUpdate();

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Book has been updated.", "Operation successfull", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "ERROR! Unable to update book.\nPlease check all info provided and try again", "Operation failed", JOptionPane.ERROR_MESSAGE);
            }

            connect.close();
            statement.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Unable to connect to database at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
                System.out.println(e);
            }catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Unable to connect to perform operation at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
                System.out.println(e);
            }
    }//GEN-LAST:event_jlblSubmitChangesMousePressed

    private void jlblRemoveMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblRemoveMousePressed
        String query;
        query = "DELETE FROM tblBooks WHERE ISBN = '" + jftxfISBN.getText() + "'";
        
        try {
            int option = JOptionPane.showConfirmDialog(null, "Are you sure you would like to proceed with this action?\nThe effects are irreversable.", "Confirm Action", JOptionPane.YES_NO_OPTION);
            
            if (option == JOptionPane.YES_OPTION) {
                Connection connect = SQLConnect.connect();
                PreparedStatement statement = connect.prepareStatement(query);
                int rows = statement.executeUpdate();
                
                if (rows > 0) {
                    JOptionPane.showMessageDialog(null, "Book has been removed.", "Operation successfull", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "ERROR! Unable to remove book.\nPlease check all info provided and try again", "Operation failed", JOptionPane.ERROR_MESSAGE);
                }
                
                statement.close();
                connect.close();
                Thread.sleep(500);
                
                LibraryManagement library = new LibraryManagement(); 
                library.book = new jfrmBook();
                library.book.setLocationRelativeTo(null);
                library.book.setVisible(true);
                dispose();
            } else {
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Unable to connect to database at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unable to connect to perform operation at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }
    }//GEN-LAST:event_jlblRemoveMousePressed

    private void jlblUpdateMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblUpdateMousePressed
        int option = JOptionPane.showConfirmDialog(null, "Are you sure you would like to proceed with this action?", "Confirm Action", JOptionPane.YES_NO_CANCEL_OPTION);
        
        if (option == JOptionPane.YES_OPTION) {
            changeComponentsState(true);
        } else {
        }
    }//GEN-LAST:event_jlblUpdateMousePressed

    private void jtxfTitleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfTitleMouseExited

    }//GEN-LAST:event_jtxfTitleMouseExited

    private void jtxfAuthorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfAuthorMouseExited
        
    }//GEN-LAST:event_jtxfAuthorMouseExited

    private void jcomboPublisherItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jcomboPublisherItemStateChanged
       
    }//GEN-LAST:event_jcomboPublisherItemStateChanged

    private void jcomboTitlesItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jcomboTitlesItemStateChanged
        String query, title, bookISBN, bookTitle, authorInitials, publicationYear, bookPublisher, publicationGenre;
        int quantity;
        double sellingPrice;
        title = String.valueOf(jcomboTitles.getSelectedItem());
        try {
            query = "SELECT * FROM tblBooks WHERE Title = ?";
            Connection connect = SQLConnect.connect();
            PreparedStatement statement = connect.prepareStatement(query);
            statement.setString(1, title);
            ResultSet set = statement.executeQuery();
            
            if (set.next()) {
               bookISBN = set.getString("ISBN");
               jftxfISBN.setText(bookISBN);
               
               bookTitle = set.getString("Title");
               jtxfTitle.setText(bookTitle);
                       
               authorInitials = set.getString("Author");
               jtxfAuthor.setText(authorInitials);
                       
               publicationYear = set.getString("PublicationYear");
               jcomboPublicationYear.setSelectedItem(publicationYear);
               
               bookPublisher = set.getString("Publisher");
               jcomboPublisher.setSelectedItem(bookPublisher);
               
               publicationGenre = set.getString("Genre");
               jcomboGenre.setSelectedItem(publicationGenre);
               
               quantity = set.getInt("Quantity");
               jtxfQuantity.setText(String.valueOf(quantity));
               
               sellingPrice = set.getDouble("SellingPrice");
               jtxfEstimatedSelling.setText(String.valueOf(sellingPrice));
               
               double rentingPrice = getRentingPrice(sellingPrice);
               double roundedRenting = Math.round(rentingPrice);
               jtxfEstimatedRent.setText(String.valueOf(roundedRenting));
                changeComponentsState(false);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid selection.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            }
            
            connect.close();
            statement.close();
            set.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Unable to connect to database at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unable to perform operation at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }
    }//GEN-LAST:event_jcomboTitlesItemStateChanged

    private void jtxfEstimatedRentMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfEstimatedRentMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxfEstimatedRentMouseExited

    private void jlblReturnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblReturnMousePressed
        LibraryManagement library = new LibraryManagement();
        library.adminMenu = new jfrmAdminMenu();
        library.adminMenu.setLocationRelativeTo(null);
        library.adminMenu.setVisible(true);
        dispose();
    }//GEN-LAST:event_jlblReturnMousePressed

    private void jtxfAuthorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxfAuthorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxfAuthorActionPerformed

    private void jtxfQuantityMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfQuantityMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxfQuantityMouseExited

    private void jtxfEstimatedSellingMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfEstimatedSellingMouseExited
        jtxfEstimatedRent.setText(String.valueOf(Math.round(getRentingPrice(Double.parseDouble(jtxfEstimatedSelling.getText())))));
    }//GEN-LAST:event_jtxfEstimatedSellingMouseExited
    
    public double getAmountOwed(){
        String publisher = (String) jcomboPublisher.getSelectedItem();
        double publisherFee = 0, finalPrice = 0;
        int quantity = (int) Integer.parseInt(jtxfEstimatedRent.getText());
        
        if (publisher.equals(publishers[0])) {
            publisherFee = 900;
        } else if (publisher.equals(publishers[1])) {
            publisherFee = 850;
        } else if (publisher.equals(publishers[2])) {
            publisherFee = 800;
        } else if (publisher.equals(publishers[3])) {
            publisherFee = 700;
        } else if (publisher.equals(publishers[4])) {
            publisherFee = 750;
        } else if (publisher.equals(publishers[5])) {
            publisherFee = 200;
        } else if (publisher.equals(publishers[6])) {
            publisherFee = 600;
        } else if (publisher.equals(publishers[7])) {
            publisherFee = 100;
        } else if (publisher.equals(publishers[8])) {
            publisherFee = 150;
        } else if (publisher.equals(publishers[9])) {
            publisherFee = 250;
        } else if (publisher.equals(publishers[10])) {
            publisherFee = 650;
        } else if (publisher.equals(publishers[11])) {
            publisherFee = 760;
        } else if (publisher.equals(publishers[12])) {
            publisherFee = 850;
        } else if (publisher.equals(publishers[13])) {
            publisherFee = 820;
        } else if (publisher.equals(publishers[14])) {
            publisherFee = 850;
        } else if (publisher.equals(publishers[15])) {
            publisherFee = 350;
        } else if (publisher.equals(publishers[16])) {
            publisherFee = 250;
        } else if (publisher.equals(publishers[17])) {
            publisherFee = 320;
        } else if (publisher.equals(publishers[18])) {
            publisherFee = 520;
        } else if (publisher.equals(publishers[19])) {
            publisherFee = 100;
        }
        
        finalPrice = publisherFee * quantity;
        return finalPrice;
    }
    
    public double getRentingPrice(double inAmount){
        int duration = 12;
        return inAmount/ duration;
    }
    
    boolean validString(String inStr){
        return inStr.matches("[a-zA-Z]+");
    }
    
    void changeComponentsState(boolean inState){
        jftxfISBN.setEnabled(false);
        jtxfTitle.setEnabled(inState);
        jcomboPublicationYear.setEnabled(inState);
        jcomboPublisher.setEnabled(inState);
        jcomboGenre.setEnabled(inState);
        jtxfEstimatedRent.setEnabled(inState);
        jtxfEstimatedSelling.setEnabled(inState);
        jtxfEstimatedRent.setEnabled(false);
    }
    
    public static String getInitials(String fullName) {
        String[] names = fullName.split(" ");
        StringBuilder initials = new StringBuilder();

        // Append the first initial of each name, except for the last name
        for (int i = 0; i < names.length - 1; i++) {
            initials.append(names[i].charAt(0)).append(". ");
        }

        // Append the last name as is
        initials.append(names[names.length - 1]);

        return initials.toString();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(jfrmBookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(jfrmBookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(jfrmBookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(jfrmBookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new jfrmBookPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JComboBox<String> jcomboGenre;
    private javax.swing.JComboBox<String> jcomboPublicationYear;
    private javax.swing.JComboBox<String> jcomboPublisher;
    private javax.swing.JComboBox<String> jcomboTitles;
    private javax.swing.JFormattedTextField jftxfISBN;
    private javax.swing.JLabel jlblAuthor;
    private javax.swing.JLabel jlblGenre;
    private javax.swing.JLabel jlblISBN;
    private javax.swing.JLabel jlblNewBook;
    private javax.swing.JLabel jlblPublicationYear;
    private javax.swing.JLabel jlblPublisher;
    private javax.swing.JLabel jlblQuantity;
    private javax.swing.JLabel jlblRemove;
    private javax.swing.JLabel jlblRent;
    private javax.swing.JLabel jlblReturn;
    private javax.swing.JLabel jlblSelling;
    private javax.swing.JLabel jlblSubmitChanges;
    private javax.swing.JLabel jlblTitle;
    private javax.swing.JLabel jlblTitle1;
    private javax.swing.JLabel jlblUpdate;
    private javax.swing.JPanel jpnlComponents;
    private javax.swing.JSeparator jsepAuthor;
    private javax.swing.JSeparator jsepAuthor1;
    private javax.swing.JSeparator jsepISBN;
    private javax.swing.JSeparator jsepRent;
    private javax.swing.JSeparator jsepSellingPrice;
    private javax.swing.JSeparator jsepTitle;
    private javax.swing.JTextField jtxfAuthor;
    private javax.swing.JTextField jtxfEstimatedRent;
    private javax.swing.JTextField jtxfEstimatedSelling;
    private javax.swing.JTextField jtxfQuantity;
    private javax.swing.JTextField jtxfTitle;
    // End of variables declaration//GEN-END:variables
}
