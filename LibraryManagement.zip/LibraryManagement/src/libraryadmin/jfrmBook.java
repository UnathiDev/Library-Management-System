/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package libraryadmin;

import java.awt.Color;
import java.awt.HeadlessException;
import java.sql.*;
import javax.swing.JOptionPane;
import librarymanagement.LibraryManagement;
import sqlconnect.SQLConnect;

/**
 * @author Unathi Okhue
 */
public class jfrmBook extends javax.swing.JFrame {
    public jfrmBook() {
        initComponents();
    }

    String[] publishers = {
        "Skye Publishing", "Ingram Content Group",
        "Baker & Taylor", "AuthorHouse",
        "The Bonoi Group", "Independent Publishers Group (IPG)",
        "Consortium Book Sales & Distribution", "Perseus Books Group",
        "Publishers Group West (PGW)", "Hachette Book Group",
        "Simon & Schuster", "HarperCollins",
        "Random House", "Bookazine",
        "Midpoint Trade Books", "Greenleaf Book Group",
        "Book Distribution Services", "Trafalgar Square Publishing",
        "Chicago Distribution Center", "National Book Network (NBN)",
        "Small Press Distribution (SPD)"
    };
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpnlBackground = new javax.swing.JPanel();
        jlblSubmit = new javax.swing.JLabel();
        jlblReset = new javax.swing.JLabel();
        jlblNewBook = new javax.swing.JLabel();
        jlblReturn = new javax.swing.JLabel();
        jspComponents = new javax.swing.JScrollPane();
        jpnlComponents = new javax.swing.JPanel();
        jtxfTitle = new javax.swing.JTextField();
        jlblTitle = new javax.swing.JLabel();
        jsepTitle = new javax.swing.JSeparator();
        jlblISBN = new javax.swing.JLabel();
        jsepISBN = new javax.swing.JSeparator();
        jsepAuthor = new javax.swing.JSeparator();
        jtxfAuthor = new javax.swing.JTextField();
        jlblAuthor = new javax.swing.JLabel();
        jlblPublisher = new javax.swing.JLabel();
        jcomboPublisher = new javax.swing.JComboBox<>();
        jcomboPublicationYear = new javax.swing.JComboBox<>();
        jlblPublicationYear = new javax.swing.JLabel();
        jcomboGenre = new javax.swing.JComboBox<>();
        jlblGenre = new javax.swing.JLabel();
        jlblQuantity = new javax.swing.JLabel();
        jspnQuantity = new javax.swing.JSpinner();
        jlblRent = new javax.swing.JLabel();
        jsepRent = new javax.swing.JSeparator();
        jsepSellingPrice = new javax.swing.JSeparator();
        jlblSelling = new javax.swing.JLabel();
        jsepAmountOwed = new javax.swing.JSeparator();
        jlblAmountOwed = new javax.swing.JLabel();
        jftxfISBN = new javax.swing.JFormattedTextField();
        jftxfAmountOwed = new javax.swing.JFormattedTextField();
        jftxfEstimatedRent = new javax.swing.JFormattedTextField();
        jftxfEstimatedSelling = new javax.swing.JFormattedTextField();
        jlblEditPrice = new javax.swing.JLabel();
        jlblViewBooks = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(771, 531));

        jpnlBackground.setBackground(new java.awt.Color(255, 255, 255));

        jlblSubmit.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblSubmit.setForeground(new java.awt.Color(51, 153, 255));
        jlblSubmit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblSubmit.setText("Submit");
        jlblSubmit.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblSubmit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblSubmitMousePressed(evt);
            }
        });

        jlblReset.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblReset.setForeground(new java.awt.Color(51, 153, 255));
        jlblReset.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblReset.setText("Reset");
        jlblReset.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblReset.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblResetMousePressed(evt);
            }
        });

        jlblNewBook.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jlblNewBook.setForeground(new java.awt.Color(51, 153, 255));
        jlblNewBook.setText("Add a new book");

        jlblReturn.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblReturn.setForeground(new java.awt.Color(51, 153, 255));
        jlblReturn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblReturn.setText("Retrun");
        jlblReturn.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblReturn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblReturnMousePressed(evt);
            }
        });

        jpnlComponents.setBackground(new java.awt.Color(255, 255, 255));

        jtxfTitle.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfTitle.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfTitle.setBorder(null);
        jtxfTitle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfTitleMouseExited(evt);
            }
        });

        jlblTitle.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblTitle.setForeground(new java.awt.Color(51, 153, 255));
        jlblTitle.setText("Title");

        jsepTitle.setForeground(new java.awt.Color(51, 153, 255));

        jlblISBN.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblISBN.setForeground(new java.awt.Color(51, 153, 255));
        jlblISBN.setText("ISBN");

        jsepISBN.setForeground(new java.awt.Color(51, 153, 255));

        jsepAuthor.setForeground(new java.awt.Color(51, 153, 255));

        jtxfAuthor.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfAuthor.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfAuthor.setBorder(null);
        jtxfAuthor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jtxfAuthorMouseExited(evt);
            }
        });

        jlblAuthor.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblAuthor.setForeground(new java.awt.Color(51, 153, 255));
        jlblAuthor.setText("Author (Full Name)");

        jlblPublisher.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblPublisher.setForeground(new java.awt.Color(51, 153, 255));
        jlblPublisher.setText("Publisher");

        jcomboPublisher.setEditable(true);
        jcomboPublisher.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboPublisher.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Skye Publishing", "Ingram Content Group", "Baker & Taylor", "AuthorHouse", "The Bonoi Group", "Independent Publishers Group (IPG)", "Consortium Book Sales & Distribution", "Perseus Books Group", "Publishers Group West (PGW)", "Hachette Book Group", "Simon & Schuster", "HarperCollins", "Random House", "Bookazine", "Midpoint Trade Books", "Greenleaf Book Group", "Book Distribution Services", "Trafalgar Square Publishing", "Chicago Distribution Center", "National Book Network (NBN)", "Small Press Distribution (SPD)" }));
        jcomboPublisher.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jcomboPublisherItemStateChanged(evt);
            }
        });

        jcomboPublicationYear.setEditable(true);
        jcomboPublicationYear.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboPublicationYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "1927", "1928", "1929", "1930", "1931", "1932", "1933", "1934", "1935", "1936", "1937", "1938", "1939", "1940", "1941", "1942", "1943", "1944", "1945", "1946", "1947", "1948", "1949", "1950", "1951", "1952", "1953", "1954", "1955", "1956", "1957", "1958", "1959", "1960", "1961", "1962", "1963", "1964", "1965", "1966", "1967", "1968", "1969", "1970", "1971", "1972", "1973", "1974", "1975", "1976", "1977", "1978", "1979", "1980", "1981", "1982", "1983", "1984", "1985", "1986", "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027" }));

        jlblPublicationYear.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblPublicationYear.setForeground(new java.awt.Color(51, 153, 255));
        jlblPublicationYear.setText("Publication Year");

        jcomboGenre.setEditable(true);
        jcomboGenre.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jcomboGenre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fantasy", "Science Fiction", "Dystopian", "Action & Adventure", "Mystery", "Horror", "Thriller & Suspense", "Romance", "Historical Fiction", "Young Adult (YA)", "Children's", "Women's Fiction", "Contemporary Fiction", "Literary Fiction", "Graphic Novel", "Short Story", "Memoir & Autobiography", "Biography", "Food & Drink", "Art & Photography", "Self-Help", "History", "Travel", "True Crime", "Humor", "Essays", "Guide/How-to", "Religion & Spirituality", "Humanities   1  & Social Sciences", "Parenting & Families", "Science & Technology" }));

        jlblGenre.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblGenre.setForeground(new java.awt.Color(51, 153, 255));
        jlblGenre.setText("Genre");

        jlblQuantity.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblQuantity.setForeground(new java.awt.Color(51, 153, 255));
        jlblQuantity.setText("Quantity");

        jspnQuantity.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jspnQuantity.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jspnQuantityStateChanged(evt);
            }
        });

        jlblRent.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblRent.setForeground(new java.awt.Color(51, 153, 255));
        jlblRent.setText("Estimated Rent Price");

        jsepRent.setForeground(new java.awt.Color(51, 153, 255));

        jsepSellingPrice.setForeground(new java.awt.Color(51, 153, 255));

        jlblSelling.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblSelling.setForeground(new java.awt.Color(51, 153, 255));
        jlblSelling.setText("Estimated Selling Price");

        jsepAmountOwed.setForeground(new java.awt.Color(51, 153, 255));

        jlblAmountOwed.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblAmountOwed.setForeground(new java.awt.Color(51, 153, 255));
        jlblAmountOwed.setText("Amount Owed to Publisher");

        jftxfISBN.setBorder(null);
        try {
            jftxfISBN.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####-#-##-######-#")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jftxfISBN.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jftxfISBN.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N

        jftxfAmountOwed.setBorder(null);
        jftxfAmountOwed.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("¤¤#,##0.00"))));
        jftxfAmountOwed.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jftxfAmountOwed.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N

        jftxfEstimatedRent.setBorder(null);
        jftxfEstimatedRent.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("¤¤#,##0.00"))));
        jftxfEstimatedRent.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jftxfEstimatedRent.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N

        jftxfEstimatedSelling.setBorder(null);
        jftxfEstimatedSelling.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("¤¤#,##0.00"))));
        jftxfEstimatedSelling.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jftxfEstimatedSelling.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N

        jlblEditPrice.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jlblEditPrice.setForeground(new java.awt.Color(51, 153, 255));
        jlblEditPrice.setText("Edit Price");
        jlblEditPrice.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblEditPriceMousePressed(evt);
            }
        });

        javax.swing.GroupLayout jpnlComponentsLayout = new javax.swing.GroupLayout(jpnlComponents);
        jpnlComponents.setLayout(jpnlComponentsLayout);
        jpnlComponentsLayout.setHorizontalGroup(
            jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlblAuthor)
                            .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jsepAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jtxfAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jlblGenre)
                            .addComponent(jcomboGenre, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlblPublisher)
                                    .addComponent(jcomboPublisher, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlblPublicationYear)
                                    .addComponent(jcomboPublicationYear, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(87, Short.MAX_VALUE))
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlblQuantity)
                                    .addComponent(jspnQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlblTitle)
                            .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jsepTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jtxfTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jlblISBN)
                            .addComponent(jsepISBN, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
                            .addComponent(jftxfISBN))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addComponent(jlblRent)
                                .addGap(30, 30, 30)
                                .addComponent(jlblSelling))
                            .addComponent(jlblAmountOwed)
                            .addComponent(jsepAmountOwed, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addComponent(jftxfAmountOwed, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jlblEditPrice))
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jsepRent, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jftxfEstimatedRent, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jftxfEstimatedSelling, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jsepSellingPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 366, Short.MAX_VALUE))))
        );
        jpnlComponentsLayout.setVerticalGroup(
            jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlblTitle, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jlblISBN))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jftxfISBN)
                            .addComponent(jtxfTitle, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE))
                        .addGap(4, 4, 4)
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jsepTitle, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jsepISBN, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlblAuthor, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jlblPublisher)
                                .addComponent(jlblPublicationYear)))
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jtxfAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(4, 4, 4)
                                .addComponent(jsepAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnlComponentsLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jcomboPublicationYear, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                                    .addComponent(jcomboPublisher))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlblGenre)
                            .addComponent(jlblQuantity))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jspnQuantity, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
                            .addComponent(jcomboGenre))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 122, Short.MAX_VALUE)
                        .addComponent(jlblAmountOwed)
                        .addGap(4, 4, 4)
                        .addComponent(jftxfAmountOwed, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnlComponentsLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jlblEditPrice)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jsepAmountOwed, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblRent)
                    .addComponent(jlblSelling))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnlComponentsLayout.createSequentialGroup()
                        .addGroup(jpnlComponentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jftxfEstimatedRent, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jftxfEstimatedSelling, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jsepRent, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jsepSellingPrice, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7))
        );

        jspComponents.setViewportView(jpnlComponents);

        jlblViewBooks.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblViewBooks.setForeground(new java.awt.Color(51, 153, 255));
        jlblViewBooks.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblViewBooks.setText("View Books");
        jlblViewBooks.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblViewBooks.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblViewBooksMousePressed(evt);
            }
        });

        javax.swing.GroupLayout jpnlBackgroundLayout = new javax.swing.GroupLayout(jpnlBackground);
        jpnlBackground.setLayout(jpnlBackgroundLayout);
        jpnlBackgroundLayout.setHorizontalGroup(
            jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                        .addComponent(jlblNewBook)
                        .addGap(0, 623, Short.MAX_VALUE))
                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                        .addComponent(jspComponents, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlblSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jlblReset, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jlblReturn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jlblViewBooks, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jpnlBackgroundLayout.setVerticalGroup(
            jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                        .addComponent(jlblViewBooks, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblReturn, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblReset, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                        .addComponent(jlblNewBook)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jspComponents, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpnlBackground, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpnlBackground, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jlblSubmitMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblSubmitMousePressed
        String bookTitle, bookISBN, authorFullNames, bookPublisher, publicationYear, publicationGenre, query;
        int quantity;
        double amountOwed, rentPrice, sellingPrice;
        
        bookTitle = jtxfTitle.getText();
        bookISBN = jftxfISBN.getText();
        authorFullNames = jtxfAuthor.getText();
        bookPublisher = (String) jcomboPublisher.getSelectedItem();
        publicationYear = (String) jcomboPublicationYear.getSelectedItem();
        publicationGenre = (String) jcomboGenre.getSelectedItem();
        quantity =  (int) jspnQuantity.getValue();
        amountOwed = Double.parseDouble(jftxfAmountOwed.getText());
        rentPrice = Double.parseDouble(jftxfEstimatedRent.getText());
        sellingPrice = Double.parseDouble(jftxfEstimatedSelling.getText());
        
        if (bookTitle == null || bookISBN == null || authorFullNames == null || bookPublisher == null || 
                publicationYear == null || publicationGenre == null || quantity == 0 || 
                jftxfAmountOwed.getText() == null || jftxfEstimatedRent.getText() == null || jftxfEstimatedSelling.getText() == null) {
            JOptionPane.showMessageDialog(null, "Missing fields.\nPlease makes sure no fields are left blank.", "Request unsuccessfull", JOptionPane.ERROR_MESSAGE);
        } else {
            try {
                query = "INSERT INTO tblBooks VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                Connection connect = SQLConnect.connect();
                PreparedStatement statement = connect.prepareStatement(query);
                
                statement.setString(1, bookISBN);
                statement.setString(2, bookTitle);
                statement.setString(3, getInitials(authorFullNames));
                statement.setString(4, String.valueOf(publicationYear));
                statement.setString(5, bookPublisher);
                statement.setString(6, publicationGenre);
                statement.setInt(7, quantity);
                statement.setDouble(8, sellingPrice);
                
                int rowsInserted = statement.executeUpdate();

                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(null, "New book recorded.", "Operation successfull", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "ERROR! Unable to record new book.\nPlease check all info provided and try again", "Operation failed", JOptionPane.ERROR_MESSAGE);
                }
                
                connect.close();
                statement.close();
            } catch (HeadlessException | SQLException e) {
                JOptionPane.showMessageDialog(null, "Unable to connect to database at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
                System.out.println(e);
            }catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Unable to connect to perform operation at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_jlblSubmitMousePressed

    private void jlblResetMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblResetMousePressed
        jtxfTitle.setText(null);
        jftxfISBN.setText(null);
        jtxfAuthor.setText(null);
        jcomboPublisher.setSelectedIndex(0);
        jcomboPublicationYear.setSelectedIndex(0);
        jcomboGenre.setSelectedIndex(0);
        jspnQuantity.setValue(0);
        jftxfAmountOwed.setText(null);
        jftxfEstimatedRent.setText(null);
        jftxfEstimatedSelling.setText(null);
    }//GEN-LAST:event_jlblResetMousePressed

    private void jlblReturnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblReturnMousePressed
        LibraryManagement library = new LibraryManagement();
        library.adminMenu = new jfrmAdminMenu();
        library.adminMenu.setLocationRelativeTo(null);
        library.adminMenu.setVisible(true);
        dispose();
    }//GEN-LAST:event_jlblReturnMousePressed

    private void jspnQuantityStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jspnQuantityStateChanged
        double amountOwed = getAmountOwed();
        jftxfAmountOwed.setText(String.valueOf(amountOwed));
        jftxfAmountOwed.setEditable(false);
        jftxfEstimatedRent.setText(String.valueOf(getRentingPrice(amountOwed)));
        jftxfEstimatedSelling.setText(String.valueOf(getSellingPrice(amountOwed)));
    }//GEN-LAST:event_jspnQuantityStateChanged

    private void jcomboPublisherItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jcomboPublisherItemStateChanged
        double amountOwed = getAmountOwed();
        jftxfAmountOwed.setText(String.valueOf(amountOwed));
        jftxfAmountOwed.setEditable(false);
        jftxfEstimatedRent.setText(String.valueOf(getRentingPrice(amountOwed)));
        jftxfEstimatedSelling.setText(String.valueOf(getSellingPrice(amountOwed)));
    }//GEN-LAST:event_jcomboPublisherItemStateChanged

    private void jlblEditPriceMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblEditPriceMousePressed
        String publisherAmount = jftxfAmountOwed.getText();
        double additionalAmount = 0, publisherPrice = Double.valueOf(publisherAmount), alteredAmount;
        JOptionPane.showMessageDialog(null, "Amount may not be lower that publisher price of R" + publisherAmount + ".", "Warning", JOptionPane.WARNING_MESSAGE);
        
        String inputValue = JOptionPane.showInputDialog(null, "Enter additional amount:");
        additionalAmount = Double.parseDouble(inputValue);
        
        alteredAmount = publisherPrice + additionalAmount;
        jftxfAmountOwed.setText(String.valueOf(alteredAmount));
    }//GEN-LAST:event_jlblEditPriceMousePressed

    private void jtxfTitleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfTitleMouseExited
        String testName = jtxfTitle.getText();
        if (validString(testName)) {
            jsepTitle.setForeground(new Color(51,153,255));
        } else {
            jsepTitle.setForeground(new Color(255,0,0));
        }
    }//GEN-LAST:event_jtxfTitleMouseExited

    private void jtxfAuthorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtxfAuthorMouseExited
        String testAuthor = jtxfAuthor.getText();
        if (validString(testAuthor)) {
            jsepAuthor.setForeground(new Color(51,153,255));
        } else {
            jsepAuthor.setForeground(new Color(255,0,0));
        }
    }//GEN-LAST:event_jtxfAuthorMouseExited

    private void jlblViewBooksMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblViewBooksMousePressed
        LibraryManagement library = new LibraryManagement();
        library.bookPage = new jfrmBookPage();
        library.bookPage.setLocationRelativeTo(null);
        library.bookPage.setVisible(true);
        dispose();
    }//GEN-LAST:event_jlblViewBooksMousePressed

    public static String getInitials(String fullName) {
        String[] names = fullName.split(" ");
        StringBuilder initials = new StringBuilder();

        // Append the first initial of each name, except for the last name
        for (int i = 0; i < names.length - 1; i++) {
            initials.append(names[i].charAt(0)).append(". ");
        }

        // Append the last name as is
        initials.append(names[names.length - 1]);

        return initials.toString();
    }
    
    public double getAmountOwed(){
        String publisher = (String) jcomboPublisher.getSelectedItem();
        double publisherFee = 0, finalPrice = 0;
        int quantity = (int) jspnQuantity.getValue();
        
        if (publisher.equals(publishers[0])) {
            publisherFee = 900;
        } else if (publisher.equals(publishers[1])) {
            publisherFee = 850;
        } else if (publisher.equals(publishers[2])) {
            publisherFee = 800;
        } else if (publisher.equals(publishers[3])) {
            publisherFee = 700;
        } else if (publisher.equals(publishers[4])) {
            publisherFee = 750;
        } else if (publisher.equals(publishers[5])) {
            publisherFee = 200;
        } else if (publisher.equals(publishers[6])) {
            publisherFee = 600;
        } else if (publisher.equals(publishers[7])) {
            publisherFee = 100;
        } else if (publisher.equals(publishers[8])) {
            publisherFee = 150;
        } else if (publisher.equals(publishers[9])) {
            publisherFee = 250;
        } else if (publisher.equals(publishers[10])) {
            publisherFee = 650;
        } else if (publisher.equals(publishers[11])) {
            publisherFee = 760;
        } else if (publisher.equals(publishers[12])) {
            publisherFee = 850;
        } else if (publisher.equals(publishers[13])) {
            publisherFee = 820;
        } else if (publisher.equals(publishers[14])) {
            publisherFee = 850;
        } else if (publisher.equals(publishers[15])) {
            publisherFee = 350;
        } else if (publisher.equals(publishers[16])) {
            publisherFee = 250;
        } else if (publisher.equals(publishers[17])) {
            publisherFee = 320;
        } else if (publisher.equals(publishers[18])) {
            publisherFee = 520;
        } else if (publisher.equals(publishers[19])) {
            publisherFee = 100;
        }
        
        finalPrice = publisherFee * quantity;
        return finalPrice;
    }
    
    public double getSellingPrice(double inAmount){
        double rate;
        int quantity = (int) jspnQuantity.getValue();
        
        inAmount /= quantity;
        rate = (inAmount * quantity) /2;
        
        return inAmount + (inAmount * rate);
    }
    
    public double getRentingPrice(double inAmount){
        int duration = 12;
        return getSellingPrice(inAmount)/ duration;
    }
    
    boolean validString(String inStr){
        return inStr.matches("[a-zA-Z]+");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(jfrmBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(jfrmBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(jfrmBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(jfrmBook.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new jfrmBook().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> jcomboGenre;
    private javax.swing.JComboBox<String> jcomboPublicationYear;
    private javax.swing.JComboBox<String> jcomboPublisher;
    private javax.swing.JFormattedTextField jftxfAmountOwed;
    private javax.swing.JFormattedTextField jftxfEstimatedRent;
    private javax.swing.JFormattedTextField jftxfEstimatedSelling;
    private javax.swing.JFormattedTextField jftxfISBN;
    private javax.swing.JLabel jlblAmountOwed;
    private javax.swing.JLabel jlblAuthor;
    private javax.swing.JLabel jlblEditPrice;
    private javax.swing.JLabel jlblGenre;
    private javax.swing.JLabel jlblISBN;
    private javax.swing.JLabel jlblNewBook;
    private javax.swing.JLabel jlblPublicationYear;
    private javax.swing.JLabel jlblPublisher;
    private javax.swing.JLabel jlblQuantity;
    private javax.swing.JLabel jlblRent;
    private javax.swing.JLabel jlblReset;
    private javax.swing.JLabel jlblReturn;
    private javax.swing.JLabel jlblSelling;
    private javax.swing.JLabel jlblSubmit;
    private javax.swing.JLabel jlblTitle;
    private javax.swing.JLabel jlblViewBooks;
    private javax.swing.JPanel jpnlBackground;
    private javax.swing.JPanel jpnlComponents;
    private javax.swing.JSeparator jsepAmountOwed;
    private javax.swing.JSeparator jsepAuthor;
    private javax.swing.JSeparator jsepISBN;
    private javax.swing.JSeparator jsepRent;
    private javax.swing.JSeparator jsepSellingPrice;
    private javax.swing.JSeparator jsepTitle;
    private javax.swing.JScrollPane jspComponents;
    private javax.swing.JSpinner jspnQuantity;
    private javax.swing.JTextField jtxfAuthor;
    private javax.swing.JTextField jtxfTitle;
    // End of variables declaration//GEN-END:variables
}
