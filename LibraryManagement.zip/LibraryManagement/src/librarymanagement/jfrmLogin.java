/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package librarymanagement;

import java.sql.*;
import javax.swing.*;
import libraryadmin.*;
import libraryuser.*;
import sqlconnect.SQLConnect;

/**
 *
 * @author Unathi Okhue
 */
public class jfrmLogin extends javax.swing.JFrame {
    public jfrmLogin() {
        initComponents();
    }
    int attempts = 0;
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpnlBackground = new javax.swing.JPanel();
        jtxfUsername = new javax.swing.JTextField();
        jpfPassword = new javax.swing.JPasswordField();
        jsepUsername = new javax.swing.JSeparator();
        jsepPassword = new javax.swing.JSeparator();
        jlblLogin = new javax.swing.JLabel();
        jlblReset = new javax.swing.JLabel();
        jlblClose = new javax.swing.JLabel();
        jlblUsername = new javax.swing.JLabel();
        jlblPassword = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jpnlBackground.setBackground(new java.awt.Color(255, 255, 255));

        jtxfUsername.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jtxfUsername.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jtxfUsername.setText("username");
        jtxfUsername.setBorder(null);

        jpfPassword.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jpfPassword.setHorizontalAlignment(javax.swing.JTextField.TRAILING);
        jpfPassword.setText("Password");
        jpfPassword.setBorder(null);

        jsepUsername.setForeground(new java.awt.Color(51, 153, 255));

        jsepPassword.setForeground(new java.awt.Color(51, 153, 255));

        jlblLogin.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblLogin.setForeground(new java.awt.Color(51, 153, 255));
        jlblLogin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblLogin.setText("Login");
        jlblLogin.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblLoginMousePressed(evt);
            }
        });

        jlblReset.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblReset.setForeground(new java.awt.Color(51, 153, 255));
        jlblReset.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblReset.setText("Reset");
        jlblReset.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblReset.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblResetMousePressed(evt);
            }
        });

        jlblClose.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblClose.setForeground(new java.awt.Color(51, 153, 255));
        jlblClose.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblClose.setText("Close");
        jlblClose.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 153, 255), 1, true));
        jlblClose.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jlblCloseMousePressed(evt);
            }
        });

        jlblUsername.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblUsername.setForeground(new java.awt.Color(51, 153, 255));
        jlblUsername.setText("Username");

        jlblPassword.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jlblPassword.setForeground(new java.awt.Color(51, 153, 255));
        jlblPassword.setText("Password");

        javax.swing.GroupLayout jpnlBackgroundLayout = new javax.swing.GroupLayout(jpnlBackground);
        jpnlBackground.setLayout(jpnlBackgroundLayout);
        jpnlBackgroundLayout.setHorizontalGroup(
            jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnlBackgroundLayout.createSequentialGroup()
                .addContainerGap(113, Short.MAX_VALUE)
                .addComponent(jlblLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jlblReset, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jlblClose, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(111, 111, 111))
            .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                .addGap(161, 161, 161)
                .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlblPassword)
                    .addComponent(jlblUsername)
                    .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jsepPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jsepUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jtxfUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jpfPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jpnlBackgroundLayout.setVerticalGroup(
            jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnlBackgroundLayout.createSequentialGroup()
                .addContainerGap(73, Short.MAX_VALUE)
                .addComponent(jlblUsername)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtxfUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(jsepUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addComponent(jlblPassword)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jpfPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jsepPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addGroup(jpnlBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblReset, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblClose, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpnlBackground, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpnlBackground, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jlblLoginMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblLoginMousePressed

    String username, password, encryptedPassword, queryLogin, queryBlockUser;
    String dbUsername, dbPassword, dbUserType;
    boolean blocked;    

    username = jtxfUsername.getText();
    password = (String) jpfPassword.getText();
    encryptedPassword = encrypt(password);

    queryLogin = "SELECT * FROM tblAdmin WHERE Username = ? AND Password = ?";

    try {
        Connection connect = SQLConnect.connect();
        PreparedStatement statement = connect.prepareStatement(queryLogin);
        statement.setString(1, username);
        statement.setString(2, encryptedPassword);

        ResultSet set = statement.executeQuery();

        if (set.next()) {
            dbUsername = set.getString("Username");
            dbPassword = set.getString("Password");
            blocked = set.getBoolean("Blocked");
            dbUserType = set.getString("UserType");

            if (blocked) {
                JOptionPane.showMessageDialog(null, "User blocked.\nPlease contact I.T. support for further assistance.", "Operation failed", JOptionPane.ERROR_MESSAGE);
            } else {
                if (dbUserType.equals("LA")) {
                    // LOGIN FOR LIBRARY ADMIN
                    LibraryManagement library = new LibraryManagement();
                    library.adminMenu = new jfrmAdminMenu();
                    library.adminMenu.setLocationRelativeTo(null);
                    library.adminMenu.setVisible(true);
                    dispose();
                } else if (dbUserType.equals("LU")) {
                    // LOGIN FOR LIBRARY USER
                    LibraryManagement library = new LibraryManagement();
                    library.stats = new jfrmStats();
                    library.stats.setLocationRelativeTo(null);
                    library.stats.setVisible(true);
                    dispose();
                }
            }
        } else {
            attempts += 1;
            if (attempts >= 3) {
                queryBlockUser = "UPDATE tblAdmin SET Blocked = true WHERE Username = ?";
                PreparedStatement statementBlock = connect.prepareStatement(queryBlockUser);
                statementBlock.setString(1, username);
                int rowsUpdated = statementBlock.executeUpdate();
                if (rowsUpdated > 0) {
                    JOptionPane.showMessageDialog(null, "User blocked.\nPlease contact I.T. support for further assistance.", "Login failed", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Unable to block user.", "Login failed", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Incorrect username or password.\nAttempt " + attempts + " of 3.", "Login failed", JOptionPane.ERROR_MESSAGE);
            }
        }

        set.close();
        statement.close();
        connect.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Unable to connect to database at the current moment.\nPlease try again later or contact I.T. support.", "Operation failed", JOptionPane.ERROR_MESSAGE);
        System.out.println(e);
    }

    }//GEN-LAST:event_jlblLoginMousePressed

    private void jlblResetMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblResetMousePressed
        String username, password;
        
        jtxfUsername.setText("username");
        jpfPassword.setText("password");
    }//GEN-LAST:event_jlblResetMousePressed

    private void jlblCloseMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblCloseMousePressed
        System.exit(0);
    }//GEN-LAST:event_jlblCloseMousePressed

    public static String encrypt(String plainText) {
        StringBuilder encryptedText = new StringBuilder();
        int shift = 4;
        for (char c : plainText.toCharArray()) {
            if (Character.isLetter(c)){
                char shiftedChar = (char) (c + shift);
                if (Character.isUpperCase(c) && shiftedChar > 'Z') {
                    shiftedChar = (char) ('A' + shiftedChar - 'Z' - 1);
                } else if (Character.isLowerCase(c) && shiftedChar > 'z') {
                    shiftedChar = (char) ('a' + shiftedChar - 'z' - 1);
                }
                encryptedText.append(shiftedChar);
            } else {
                encryptedText.append(c);
            }
        }
        return encryptedText.toString();
    }
    
    public static void main(String args[]) throws ClassNotFoundException {

        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
        * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
        */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(jfrmLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(jfrmLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(jfrmLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(jfrmLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new jfrmLogin().setVisible(true);
            }
        });
        //</editor-fold>
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jlblClose;
    private javax.swing.JLabel jlblLogin;
    private javax.swing.JLabel jlblPassword;
    private javax.swing.JLabel jlblReset;
    private javax.swing.JLabel jlblUsername;
    private javax.swing.JPasswordField jpfPassword;
    private javax.swing.JPanel jpnlBackground;
    private javax.swing.JSeparator jsepPassword;
    private javax.swing.JSeparator jsepUsername;
    private javax.swing.JTextField jtxfUsername;
    // End of variables declaration//GEN-END:variables
}
