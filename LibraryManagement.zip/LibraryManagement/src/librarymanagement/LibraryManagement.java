/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package librarymanagement;

import libraryadmin.*;
import libraryuser.*;

/**
 * A Library Management System
 * @author Unathi Okhue
 */
public class LibraryManagement {
    public jfrmSplash splash;
    public jfrmLogin login;
    public jfrmSignIn signIn;
    public jfrmAdminMenu adminMenu;
    public jfrmUserMenu userMenu;
    public jfrmBook book;
    public jfrmBookPage bookPage;
    public jfrmMember member;
    public jfrmMemberMenu memberMenu;
    public jfrmMemberView memberView;
    public jfrmMemberList memberList;
    public jfrmAdmin admin;
    public jfrmStats stats;
    
    public static void main(String[] args) throws InterruptedException {
        try {
            LibraryManagement library = new LibraryManagement(); 
            library.splash = new jfrmSplash();
            library.splash.setLocationRelativeTo(null);
            library.splash.setVisible(true);

            Thread.sleep(10000);
            library.splash.dispose();
            library.signIn = new jfrmSignIn();
            library.signIn.setLocationRelativeTo(null);
            library.signIn.setVisible(true);
        } catch (Exception e) {
            System.out.println(e);
        }
    } 
}
